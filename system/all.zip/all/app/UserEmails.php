<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use SendGrid\Mail\Mail;

class UserEmails extends Model
{
    const apiKey = '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';
    public static function signUpEmail($email, $link){
        $email = new Mail();
        $email->setFrom("contact@jynx.co.za", "Jynx Contact");
        $email->setSubject("Welcome to Jynx");
        $email->addTo($email);
        $email->addContent(
            "text/html", "                
                <div style='background-color:#d4d3dc;padding:20px'>
                    <div style='max-width:600px;margin:0 auto'>
                        <div style='background:#fff;font:14px sans-serif;color:#686f7a;border-top:4px solid #ce171f;margin-bottom:20px;border-bottom: 4px solid #ce171f;'>
                            <div class='border-bottom:1px solid #f2f3f5;padding:20px 30px'>
                                <img src=\"http://stakeinn.com/stake/assets/img/StakeinnNew.png\" alt='Jynx' style='max-width:115px;display:block;margin: 10px 29px;'>
                            </div>
                            <div style='padding:20px 30px'>
                                <div style='font-size:16px;line-height:1.5em;border-bottom:1px solid #f2f3f5;padding-bottom:10px;margin-bottom:20px'>
                                    <p><a style='text-decoration:none;color:#000'>Welcome <strong>".$user->name."</strong>,</a></p>
                                    <p><a style='text-decoration:none;color:#000'>Thank You for registration on our website.</a></p>
                                    <p><a style='text-decoration:none;color:#000'>Your Account Verification Code:</a></p>
                                    <a target='_blank' style='font-size:16px;color:#ffffff;text-decoration:none;border-radius:2px;background-color:#ff5d03;border-top:12px solid #ff5d03;border-bottom:12px solid #ff5d03;border-right:18px solid #ff5d03;border-left:18px solid #ff5d03;display:inline-block'>
                                        '.$link.'
                                    </a>
                                    <p><a style='text-decoration:none;color:#000'><strong>Note:</strong> Contact us <strong><a href='https://jynx.co.za' target='_blank'>Here</a></strong> immediately if you did not authorize this registration.</a></p>
                                </div>
                            </div>
                        </div>
                        <div style='font:11px sans-serif;color:#3e3e3e'>
                            Delivered by jynx.co.za - All Rights Reserved.
                        </div>
                    </div>
                </div>"
        );
        self::sendEmail($email);
    }
    public static function sendEmail($email){
        $sendgrid = new \SendGrid(self::apiKey);
        try {
            $response = $sendgrid->send($email);
        } catch (\Exception $e) {
            echo 'Caught exception: '. $e->getMessage() ."\n";
        }
    }
}
