
<?php $__env->startSection('pageTitle','Create Item'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row column_title">
          <div class="col-md-12">
            <div class="page_title">
              <h2>Create Item</h2>
            </div>
          </div>
        </div>
         <!-- row -->
        <div class="row">
            <!-- table section -->
          <div class="col-md-12">
            <div class="white_shd full margin_bottom_30">
              <div class="full graph_head">
                <div class="heading1 margin_0">
                  <h2></h2>
                </div>
              </div>
              <form class="container-fluid" action="/create_item" method="POST" enctype="multipart/form-data" style="padding:30px; padding-bottom:40px;">
                <?php echo csrf_field(); ?>
                <div>
                  <label class="form-label">Category Name</label>
                  <select class="form-control" name="category_id">
                    <option>-- SELECT --</option>
                    <?php $__currentLoopData = $item_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <br>
                <div>
                  <label class="form-label">Item Name</label>
                  <input type="text" name="item_name" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Item Short Description</label>
                  <textarea name="item_short_description" rows="6" class="form-control" required></textarea>
                </div>
                <br>
                <div>
                  <label class="form-label">Item Description</label>
                  <textarea name="item_description" rows="6" class="form-control" required></textarea>
                </div>
                <br>
                <div>
                  <label class="form-label">Item Image</label>
                  <input type="file" name="item_image" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Item Price</label>
                  <input type="text" name="item_price" class="form-control" required >
                </div>
                <br>
                <?php if($attributes): ?>
                  <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-group">
                      <label for="groups"><?php echo e($v['attribute_data']['name']); ?></label>
                      <select class="form-control select_group" id="attributes_value_id" name="attributes_value_id[]" multiple="multiple">
                        <?php $__currentLoopData = $v['attribute_value']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k2 => $v2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($v2['id']); ?>"><?php echo e($v2['value']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                    </div>    
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div id="voucher">
                  <label class="form-label">Entries</label>
                  <input type="text" name="entries" class="form-control" >
                </div>
                <br>
                <div class="row" style="padding-top:10px;padding-left:30px;">
                  <button type="submit" class="btn btn-primary  my-button col-md-2 link-light col-sm-4">Create</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jynxcujg/public_html/system/resources/views/item/add.blade.php ENDPATH**/ ?>