
<?php $__env->startSection('pageTitle','User Event Details'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row column_title">
          <div class="col-md-12">
            <div class="page_title">
              <h2>User Event Details</h2>
            </div>
          </div>
        </div>
         <!-- row -->
        <div class="row">
            <!-- table section -->
          <div class="col-md-12" >
            <div class="white_shd full margin_bottom_30">
                <div class="full graph_head">
                    <div class="heading1 margin_0">
                      <h2>User Detail</h2>
                    </div>
                    <?php
                        $events = \App\Models\Event::where('id',$event->event_id)->first();
                        $user = \App\Models\user_infos::where('user_id',$event->user_id)->first();
                    ?>
                </div>
                <div class="row p-3">
                    <div class="col-6">
                        <h5>First Name:</h5>
                    </div>
                    <div class="col-6">
                        <h5><?php echo e($user->first_name); ?></h5>
                        
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">
                        <h5>Last Name:</h5>
                    </div>
                    <div class="col-6">
                        <h5><?php echo e($user->last_name); ?></h5>
                        
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-sm-3">
                        <h5>Email:</h5>
                    </div>
                    <div class="col-sm-9">
                        <h5><?php echo e($user->email); ?></h5>
                        
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">
                        <h5>Phone Number:</h5>
                    </div>
                    <div class="col-6">
                        <h5><?php echo e($user->phone_number); ?></h5>
                        
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">
                        <h5>Gender:</h5>
                    </div>
                    <div class="col-6">
                        <h5><?php echo e($user->gender); ?></h5>
                        
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">
                        <h5>Date of Birth:</h5>
                    </div>
                    <div class="col-6">
                        <h5><?php echo e($user->dob); ?></h5>
                        
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">
                        <h5>Identification Type:</h5>
                    </div>
                    <div class="col-6">
                        <?php if( $user->identification_type == 1): ?>
                            <h5>South African ID</h5>                            
                        <?php else: ?>
                            <h5>Passport</h5>
                        <?php endif; ?>
                        
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">
                        <h5>Identification Number:</h5>
                    </div>
                    <div class="col-6">
                        <h5><?php echo e($user->identification_num); ?></h5>
                        
                    </div>
                </div>
                <?php if( $user->identification_type == 1): ?>
                    <?php
                        $dha_profile = \App\Models\Dha_profile::where('user_id',$event->user_id)->first();
                    ?>
                    <?php if(!empty($dha_profile)): ?>
                    <div class="full graph_head">
                        <div class="heading1 margin_0">
                            <h2>DHA Detail</h2>
                        </div>
                    </div>               
                    <div class="row p-3">
                        <div class="col-6">
                            <h5>Name:</h5>
                        </div>
                        <div class="col-6">
                            <h5><?php echo e($dha_profile->personName); ?> <?php echo e($dha_profile->personSurname); ?></h5>
                            
                        </div>
                    </div>
                    <div class="row p-3">
                        <div class="col-6">
                            <h5>Gender:</h5>
                        </div>
                        <div class="col-6">
                            <h5><?php echo e($dha_profile->gender); ?></h5>
                            
                        </div>
                    </div>
                    <div class="row p-3">
                        <div class="col-6">
                            <h5>Date of Birth:</h5>
                        </div>
                        <div class="col-6">
                            <h5><?php echo e($dha_profile->dateOfBirth); ?></h5>
                            
                        </div>
                    </div>
                    <div class="row p-3">
                        <div class="col-6">
                            <h5>Status:</h5>
                        </div>
                        <div class="col-6">
                            <h5><?php echo e($dha_profile->aliveStatus); ?></h5>
                            
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="full graph_head">
                    <div class="heading1 margin_0">
                      <h2>Event Detail</h2>
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">
                        <h5>Event Name:</h5>
                    </div>
                    <div class="col-6">
                        <h5><?php echo e($events->event_name); ?></h5>
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">                        
                        <h5>Event Date:</h5>
                    </div>
                    <div class="col-6">
                        <h5><?php echo e($events->event_date); ?></h5>
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">                        
                        <h5>Event Description:</h5>
                    </div>
                    <div class="col-6">
                        <h5><?php echo e($events->event_short_description); ?></h5>
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">                        
                        <h5>Event Type:</h5>
                    </div>
                    <div class="col-6">
                        <?php if($events->event_type == 1 ): ?>
                            <h5>Normal</h5>
                        <?php else: ?>
                            <h5>VIP</h5>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="full graph_head">
                    <div class="heading1 margin_0">
                      <h2>User Event Detail</h2>
                    </div>
                </div>
                <div class="row p-3">
                    <div class="col-6">
                        <h5>Status:</h5>
                    </div>
                    <div class="col-6">
                        <?php if($event->qr_code_status == "1"): ?>
                            <h5>Entered at <?php echo e($event->enter_at); ?></h5>
                        <?php elseif($event->qr_code_status == "2"): ?>
                            <h5>Exited at <?php echo e($event->exit_at); ?></h5>
                        <?php elseif($event->qr_code_status == "-1"): ?>
                            <h5>Denied at <?php echo e($event->denied_at); ?></h5>
                        <?php elseif($event->qr_code_status == "0"): ?>
                            <h5><?php echo e($event->status); ?></h5>
                        <?php elseif($event->qr_code_status == "3"): ?>
                            <h5>Not going</h5>
                        <?php endif; ?>
                    </div>
                    
                </div>
            </div>
          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jynxcujg/public_html/system/resources/views/event/viewDetails.blade.php ENDPATH**/ ?>