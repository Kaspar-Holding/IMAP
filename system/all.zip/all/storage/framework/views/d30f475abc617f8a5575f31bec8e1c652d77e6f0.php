<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn btn-danger text-white text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\Laravel\resources\views/vendor/jetstream/components/danger-button.blade.php ENDPATH**/ ?>