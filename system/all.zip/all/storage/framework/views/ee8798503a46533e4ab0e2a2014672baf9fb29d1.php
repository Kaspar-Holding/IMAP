<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
  <br>
  
  <div class="container bg-white" style="background-image: <?php echo e(asset('img/sold.png')); ?>;">
      <br>
      <div class="row">
          <div class="col-xd-12 col-sm-10 ">
              <h2><?php echo e($cars_data[0]['car_name']); ?> (<?php echo e(str_replace('-',"_",substr($cars_data[0]['created_at'],0,7)) . '_' . $cars_data[0]['id']); ?>) Details</h2><br>
          </div>
      </div>
      <?php $__currentLoopData = $cars_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <form class="container " action="/edit_car" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6">
                    <h5>Car Name:</h5>
                </div>
                <div class="col-6">
                    <input type="text" class="form-control h5" name="car_name" value="<?php echo e($car['car_name']); ?>" id="">
                </div>
            </div>
            <div class="row d-none">
                <div class="col-6">
                    <h5>Car Key:</h5>
                </div>
                <div class="col-6">
                    <input type="number"  class="form-control h5" name="car_key" value="<?php echo e($car['id']); ?>" id="">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Chassis Number:</h5>
                </div>
                <div class="col-6">
                    <input type="text" class="form-control h5" readonly name="chassis_number" value="<?php echo e($car['chassis_number']); ?>" id="">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Container Number:</h5>
                </div>
                <div class="col-6">
                    <input type="text" class="form-control h5" readonly name="container_number" value="<?php echo e($car['container_number']); ?>" id="">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Purchase Date:</h5>
                </div>
                <div class="col-6">
                    <input type="date" class="form-control h5" name="date" value="<?php echo e($car['date']); ?>" id="">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Car Model:</h5>
                </div>
                <div class="col-6">
                    <input type="text" class="form-control h5" name="model" value="<?php echo e($car['model']); ?>" id="">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Car Colour:</h5>
                </div>
                <div class="col-6">
                    <input type="text" class="form-control h5" name="colour" value="<?php echo e($car['colour']); ?>" id="">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Car Engine Size:</h5>
                </div>
                <div class="col-6">
                    <input type="text" class="form-control h5" name="engine" value="<?php echo e($car['engine']); ?>" id="">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Car Price:</h5>
                </div>
                <div class="col-6">
                    <h5>$ <?php echo e($car['japanese_price']+$car['japan_to_durban_price']+$car['durban_to_botswana']+$car['repair_charges']+$car['duty']+$car['vat']); ?></h5>
                </div>
            </div>
            <hr>
            <h4>Car Price Breakdown</h4>
            <hr>
            <div class="row">
                <div class="col-6">
                    <h5>Japanese Price:</h5>
                </div>
                <div class="col-6">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon3">$</span>
                        <input type="number" class="form-control" name="japanese_price" value="<?php echo e($car['japanese_price']); ?>"  id="basic-url" aria-describedby="basic-addon3" required>
                    </div>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Japan to Durban Charges:</h5>
                </div>
                <div class="col-6">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon3">$</span>
                        <input type="number" class="form-control" name="japan_to_durban_price" value="<?php echo e($car['japan_to_durban_price']); ?>"  id="basic-url" aria-describedby="basic-addon3" required>
                    </div>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Durban to Botswana Charges:</h5>
                </div>
                <div class="col-6">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon3">$</span>
                        <input type="number" class="form-control" name="durban_to_botswana_price" value="<?php echo e($car['durban_to_botswana_price']); ?>"  id="basic-url" aria-describedby="basic-addon3" required>
                    </div>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Repair Charges:</h5>
                </div>
                <div class="col-6">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon3">$</span>
                        <input type="number" class="form-control" name="repair_charges" value="<?php echo e($car['repair_charges']); ?>"  id="basic-url" aria-describedby="basic-addon3" required>
                    </div>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Duty:</h5>
                </div>
                <div class="col-6">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon3">$</span>
                        <input type="number" class="form-control" name="duty" value="<?php echo e($car['duty']); ?>"  id="basic-url" aria-describedby="basic-addon3" required>
                    </div>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>V.A.T.:</h5>
                </div>
                <div class="col-6">
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon3">$</span>
                        <input type="number" class="form-control" name="vat" value="<?php echo e($car['vat']); ?>"  id="basic-url" aria-describedby="basic-addon3" required>
                    </div>
                </div>
            </div>
            <br>
            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-primary link-light col-sm-4">Update</button>
            </div>
            <br>
          </form>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  




  



  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.welcome','data' => []]); ?>
<?php $component->withName('jet-welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\KASPAR PROJECTS\Web App for Botswana\resources\views/edit_car_details.blade.php ENDPATH**/ ?>