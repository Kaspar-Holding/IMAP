
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row column_title">
          <div class="col-md-12">
            <div class="page_title">
              <h2>Create Event</h2>
                 
             </div
             <div><img class="event_banner" src="<?php echo e(asset('new/images/banner2.jpg')); ?>"/></div>
          </div>
        </div>
         <!-- row -->
        <div class="row">
            <!-- table section -->
          <div class="col-md-12">
            <div class="white_shd full margin_bottom_30">
              <div class="full graph_head">
                <div class="heading1 margin_0">
                 
                </div>
              </div>
              <form class="container-fluid" action="/create_event" method="POST" enctype="multipart/form-data" style="padding:30px;">
                <?php echo csrf_field(); ?>
                <div>
                  <label class="form-label">Event Name</label>
                  <input type="text" name="event_name" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Event Short Description</label>
                  <textarea name="event_short_description" rows="4" class="form-control" required></textarea>
                </div>
                <br>
                <div>
                  <label class="form-label">Event Description</label>
                  <textarea name="event_description" rows="6" class="form-control" required></textarea>
                </div>
                <br>
                <div>
                  <label class="form-label">Event Image</label>
                  <input type="file" name="event_image" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Event Date</label>
                  <input type="date" name="event_date" id="txtDate" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Event Start Time</label>
                  <input type="time" name="event_start_time" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Event End Time</label>
                  <input type="time" name="event_end_time" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Stage 1</label>
                  <input type="text" name="stage_1" class="form-control" >
                </div>
                <br>
                <div>
                  <label class="form-label">Stage 2</label>
                  <input type="text" name="stage_2" class="form-control" >
                </div>
                <br>
                <div>
                  <label class="form-label">Stage 3</label>
                  <input type="text" name="stage_3" class="form-control" >
                </div>
                <br>
                <div>
                  <label class="form-label">Special</label>
                  <input type="text" name="special" class="form-control" >
                </div>
                <br>
                <div class="row">
                  <button type="submit" class="btn btn-primary col-md-2 my-button link-light col-sm-4">Create</button>
                </div>
               
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jynxcujg/public_html/system/resources/views/event/add.blade.php ENDPATH**/ ?>