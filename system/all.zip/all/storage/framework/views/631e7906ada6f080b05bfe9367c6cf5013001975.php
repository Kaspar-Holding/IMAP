
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="row">
            <div class="col-xd-12 col-sm-8 ">
                <h2>Users Lists</h2><br>
            </div> 
            <div class="col-xd-12 col-sm-4">
                <a class="btn btn-inverse btn-outline-primary" href="<?php echo e(route('manage_permissions')); ?>">Manage Permissions</a>
                <a class="btn btn-inverse btn-outline-primary" href="<?php echo e(route('add_new_user')); ?>">Add New User</a>
            </div>
            <div>
                <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Role</th>
                    <!-- <th scope="col">Status</th> -->
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $count = 1;?>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($count); ?></td>
                    <td><?php echo e($user['name']); ?></td>
                    <td><?php echo e($user['email']); ?></td>
                    <td class="text-capitalize"><?php echo e($user['role']); ?></td>
                    <td>
                        <a href="/view_user_details/<?php echo e($user['id']); ?>" class="btn btn-sm btn-inverse btn-outline-primary">
                            <i class="fas fa-eye "></i>
                        </a>
                        <a href="/edit_user_details/<?php echo e($user['id']); ?>" class="btn btn-sm btn-inverse btn-outline-dark">
                            <i class="fas fa-pencil-alt "></i>
                        </a>
                        <a class="btn btn-sm btn-inverse btn-outline-danger" href="/delete_user/<?php echo e($user['id']); ?>"><i class="fas fa-trash-alt"></i></a>
                    </td>
                  </tr>
                  <?php $count = $count+1;?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($users->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/users/list.blade.php ENDPATH**/ ?>