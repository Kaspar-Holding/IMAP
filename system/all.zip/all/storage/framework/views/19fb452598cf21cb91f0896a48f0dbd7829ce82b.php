
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="row mb-3">
            <!-- Area Chart -->
            <div class="col-xl-8 col-lg-7">
              <div class="card mb-4" style="border-radius:20px;">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between" style="border-radius:20px;">
                  <h6 class="m-0 font-weight-bold text-primary">Monthly Sale Report</h6>
                </div>
                <div class="card-body">
                  <div class="chart-area">
                    <canvas id="myAreaChart"></canvas>
                  </div>
                </div>
              </div>
            </div>
            <!-- Pie Chart -->
            <div class="col-xl-4 col-lg-5">
                <div class="card shadow mb-4" style="border-radius:20px;">
                    <div class="card-header py-3" style="border-radius:20px;">
                        <h6 class="m-0 font-weight-bold text-primary">Car Record</h6>
                    </div>
                    <div class="card-body" style="height:16.5rem;">
                        <div class="chart-pie">
                            <canvas id="myPieChart"></canvas>
                        </div>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
        <!-- <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="./">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>
        </div> --> 
        <div class="card customBorder">
            <?php if($pendings > 0): ?>
            <div class="card-header h6 pb-3" style="color:white">
                <p class="alertbox"><?php echo e($pendings); ?> Pending Installments <a href="/view_pending_installments" class="btn btn-sm btn-inverse btn-outline-light text-right">See Record</a></p>
            </div>
            <?php endif; ?>
            <div class="card-header h6 bg-custom" style="color:white; padding:22px;">
                
            </div>
            <form action="<?php echo e(request()->fullUrl()); ?>" method="get">
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="row">
                            <div class="col-sm-6 col-12">
                                <span style="color: #545353; padding-left: 15px; font-size: 15px;">Container</span>
                                <div class="input-group customGroup p-2 mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text" id="basic-addon1"><i class="far fa-cube"></i></span>
                                    </div>
                                    <input type="text" class="form-control" placeholder="12345678" name="container" value="<?php echo e(request()->get('container')); ?>">
                                </div>
                            </div>
                            <div class="col-sm-6 col-12">
                                <span style="color: #545353; padding-left: 15px; font-size: 15px;">Car Key</span>
                                <div class="input-group customGroup p-2 mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text" id="basic-addon1"><i class="fa fa-key"></i></span>
                                    </div>
                                    <input type="text" class="form-control"  placeholder="Car Key" name="car_key" value="<?php echo e(request()->get('car_key')); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="row">
                            <div class="col-sm-5 col-12">
                                <span style="color: #545353; padding-left: 15px; font-size: 15px;">Start Date</span>
                                <div class="input-group customGroup p-2 mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text" id="basic-addon1"><i class=" fa fa-calendar"></i></span>
                                    </div>
                                    <input type="date" class="form-control" value="<?php echo e(Carbon\Carbon::parse($first_date->created_at)->format('Y-m-d')); ?>" placeholder="From Date" name="from_date">
                                </div>
                            </div>
                            <div class="col-sm-5 col-12">
                                <span style="color: #545353; padding-left: 15pfx; font-size: 15px;">End Date</span>
                                <div class="input-group customGroup p-2 mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text" id="basic-addon1"><i class="fa fa-calendar"></i></span>
                                    </div>
                                    <input type="date" class="form-control" value="<?php echo e(Carbon\Carbon::now()->format('Y-m-d')); ?>" placeholder="To Date" name="to_date" aria-label="To Date">
                                </div>
                                <!-- <?php if(request()->get('container') || request()->get('car_key') || request()->get('from_date') || request()->get('to_date')): ?>
                                    <a class="btn btn-primary btn-sm mt-2 text-white" href="<?php echo e(route('dashboard')); ?>">Reset</a>
                                <?php endif; ?> -->
                            </div>
                            <div class="col-sm-2 col-12" style="align-self:center;">
                                <button style="background-color:#fb6d3a"; type="submit" class="btn btn-inverse"><i style="background-color:#fb6d3a; color:white;"class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </form>
        </div>
        <br>
        <div class="card customBorder">
            <div class="card-header h6 bg-custom" style="color:white;">
            <img src="<?php echo e(asset('img/inventory.png')); ?>">    Inventory
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox" style="height:4rem!important;">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/icon_1.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-text h4"><?php echo e($cars_count); ?></p>
                                            <h6 class="card-title text-muted textNewSize">Cars bought</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 20px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox" style="height:4rem!important;">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/icon_2.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-text h4"><?php echo e($cars_sold); ?></p>
                                            <h6 class="card-title text-muted textNewSize">Sold Cars</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 20px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox" style="height:4rem!important;">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/icon_4.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-text h4"><?php echo e($cars_available); ?></p>
                                            <h6 class="card-title text-muted textNewSize">Available Cars</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 20px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-12">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox" style="height:4rem!important;">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/icon_3.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-text h4"><?php echo e($containers_count); ?></p>
                                            <h6 class="card-title text-muted textNewSize">Containers</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 20px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
        </div>
        <br>
        <div class="card customBorder">
            <div class="card-header h6 bg-custom" style="color:white; padding:3px;">
            <img src="<?php echo e(asset('img/sale.png')); ?>">    Sales and Orders
            </div>
            <div class="card-body border-secondary border-2">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_1.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-text h4"><?php echo e($japanese_price+$shipment_cost+$duty_n_vat+$repairs); ?></p>
                                            <h6 class="card-title text-muted textNewSize">Total Expenditures</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_2.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-text h4">$ <?php echo e($japanese_price); ?></p>
                                            <h6 class="card-title text-muted textNewSize">Japanese Price</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_3.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-text h4">$ <?php echo e($shipment_cost); ?></p>
                                            <h6 class="card-title text-muted textNewSize">Shipment Cost</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_4.png')); ?>">
                                        </div>
                                        <div class="col-sm-6s col-6">
                                            <p class="card-text h4"><?php echo e($duty_n_vat); ?></p>
                                            <h6 class="card-title text-muted textNewSize">Duty and V.A.T.</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body border-secondary border-2">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_5.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-text h4"><?php echo e($repairs); ?></p>
                                            <h6 class="card-title text-muted textNewSize">Repair Expenditures</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_6.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-title h4"><?php echo e($selling_amount); ?></p>
                                            <h6 class="card-text text-muted textNewSize">Selling Amount</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_11.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-title h4"><?php echo e($total_cheque_payment); ?></p>
                                            <h6 class="card-text text-muted textNewSize">Paid By Cheque</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_7.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-title h4"><?php echo e($total_cash_payment+$installment_paid); ?></p>
                                            <h6 class="card-text text-muted textNewSize">Paid By Cash</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                    
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_8.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-title h4"><?php echo e(($selling_amount-$total_cheque_payment)-($total_cash_payment+$installment_paid)); ?></p>
                                            <h6 class="card-text text-muted textNewSize">Pending Cash</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <?php if($installment_cars > 0): ?>
                        <a href="<?php echo e(route('installment_cars')); ?>" style="text-decoration: none;">
                        <?php endif; ?>
                        <div class="card customGroup">
                            <div class="card-body p-0" id="left">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_9.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-title h4 text-black"><?php echo e($installment_cars); ?></p>
                                            <h6 class="card-text text-muted text-black textNewSize">Installments Cars</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px; color: #757575;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if($installment_cars > 0): ?>
                        </a>
                        <?php endif; ?>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <?php if($installment_pending > 0): ?>
                        <a href="<?php echo e(route('pending_installments_cars')); ?>" style="text-decoration: none;">
                        <?php endif; ?>
                        <div class="card customGroup">
                            <div class="card-body p-0">
                                <div class="m-2 customDesignBox">
                                    <div class="row p-2">
                                        <div class="col-sm-4 col-4 m-auto text-center">
                                        <img src="<?php echo e(asset('img/sale_10.png')); ?>">
                                        </div>
                                        <div class="col-sm-6 col-6">
                                            <p class="card-title h4 text-black"><?php echo e($installment_pending); ?></p>
                                            <h6 class="card-text text-muted text-black textNewSize">Pending Installments</h6>
                                        </div>
                                        <div class="col-sm-2 col-2">
                                        <i style="padding: 0px; padding-top: 32px; color: #757575;"class="fa fa-chevron-right" aria-hidden="true"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if($installment_pending > 0): ?>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <br>
        
    </div>
    <input type="hidden" id="january" value="<?php echo e($january); ?>">
    <input type="hidden" id="feburary" value="<?php echo e($feburary); ?>">
    <input type="hidden" id="march" value="<?php echo e($march); ?>">
    <input type="hidden" id="april" value="<?php echo e($april); ?>">
    <input type="hidden" id="may" value="<?php echo e($may); ?>">
    <input type="hidden" id="june" value="<?php echo e($june); ?>">
    <input type="hidden" id="july" value="<?php echo e($july); ?>">
    <input type="hidden" id="august" value="<?php echo e($august); ?>">
    <input type="hidden" id="september" value="<?php echo e($september); ?>">
    <input type="hidden" id="october" value="<?php echo e($october); ?>">
    <input type="hidden" id="november" value="<?php echo e($november); ?>">
    <input type="hidden" id="december" value="<?php echo e($december); ?>">
    <input type="hidden" id="totalcars" value="<?php echo e($cars_count); ?>">
    <input type="hidden" id="soldcars" value="<?php echo e($cars_sold); ?>">
    <input type="hidden" id="availablecars" value="<?php echo e($cars_available); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>