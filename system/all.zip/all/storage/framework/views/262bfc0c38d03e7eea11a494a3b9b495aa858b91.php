<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Add New Car</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form class="container " action="/add_new_car" method="POST">
            <?php echo csrf_field(); ?>
            <?php 
              $mytime = Carbon\Carbon::now()->format('Y_m_');
            ?>
            <div>
                <label class="form-label">Container Number</label>
                <div class="input-group mb-3">
                  <span class="input-group-text" id="basic-addon3"><?php echo $mytime; ?></span>
                  <input type="number" class="form-control" name="container_number" id="basic-url" aria-describedby="basic-addon3" required>
                </div>
            </div>
            <div>
                <label class="form-label">Car Name</label>
                <input type="text" name="car_name" class="form-control"required >
                <div class="form-text">Please Enter the Unique Car Chassis Number</div>
            </div>
            <div>
                <label class="form-label">Car Chassis Number</label>
                <input type="text" name="chassis_number" class="form-control"required >
                <div class="form-text">Please Enter the Unique Car Chassis Number</div>
            </div>
            <div>
                <label class="form-label">Car Model</label>
                <input type="text" name="model" class="form-control" required>
                <div class="form-text">Please Enter the Car Model</div>
            </div>
            <div>
                <label class="form-label">Car Colour</label>
                <input type="text" name="colour" class="form-control" required>
                <div class="form-text">Please Enter the Car Colour</div>
            </div>
            <div>
                <label class="form-label">Car Engine Size</label>
                <input type="text" name="engine" class="form-control" required>
                <div class="form-text">Please Enter the Car Engine Size</div>
            </div>
            <div>
                <label class="form-label">Car Purchase Date</label>
                <input type="date" name="date" class="form-control" required>
                <div class="form-text">Please Enter the Car Engine Size</div>
            </div>
            <div>
                <label class="form-label">Japanese Price</label>
                <input type="number" name="japanese_price" class="form-control" required>
                <div class="form-text">Please Enter the Japanese Price of the Car</div>
            </div>
            <div>
                <label class="form-label">Japan To Durban Ship Charges</label>
                <input type="number" name="japan_to_durban" class="form-control" required>
                <div class="form-text">Please Enter the Japan to Durban Ship Charges of the Car</div>
            </div>
            <div>
                <label class="form-label">Durban To Botswana Shipement Charges</label>
                <input type="number" name="durban_to_botswana" class="form-control" required>
                <div class="form-text">Please Enter the Durban To Botswana Shipement Charges of the Car</div>
            </div>
            <div>
                <label class="form-label">Repairs</label>
                <input type="number" name="repair" class="form-control" required>
                <div class="form-text">Please Enter the Repair Charges of the Car</div>
            </div>
            <div>
                <label class="form-label">Duty</label>
                <input type="number" name="duty" class="form-control" required>
                <div class="form-text">Please Enter the Duty of the Car</div>
            </div>
            <div>
                <label class="form-label">V.A.T.</label>
                <input type="number" name="vat" class="form-control" required>
                <div class="form-text">Please Enter V.A.T. Charges of the Car</div>
            </div>
            <br>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary link-light col-sm-4">ADD</button>
            </div>
            <div class="d-flex justify-content-center">
                
            </div>
            
          </form>
        </div>
        
      </div>
    </div>
  </div><?php /**PATH D:\KASPAR PROJECTS\Web App for Botswana\resources\views/add_new_car.blade.php ENDPATH**/ ?>