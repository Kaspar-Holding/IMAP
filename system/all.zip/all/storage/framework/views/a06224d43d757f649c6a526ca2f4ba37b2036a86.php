
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="card customBorder">
            <div class="card-header h6 bg-custom" style="color:white">
                <i class="far fa-chart-bar"></i>    Petty Cash Total Amount
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-6 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom">
                                <div class="row">
                                    <div class="col-lg-4 col-8">
                                        <p class="card-text h3"><?php echo e($total_cheque_payment); ?></p>
                                        <h6 class="card-title text-muted">Total Cheque Amount</h6>
                                    </div>
                                    <div class="col-lg-3 col-4">
                                        <i class="fal fa-money-check-alt fa-3x"></i>
                                    </div>
                                    <div class="col-lg-5 col-12">
                                        <p class="card-text h3"><?php echo e($total_cheque_payment-$total_cheque_debit); ?></p>
                                        <h6 class="card-title text-muted">Remaining Cheque Amount</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg-4 col-8">
                                        <p class="card-text h3"><?php echo e($total_cash_payment+$installment_paid); ?></p>
                                        <h6 class="card-title text-muted">Total Cash Amount</h6>
                                    </div>
                                    <div class="col-lg-3 col-4">
                                        <i class="fal fa-money-bill-wave fa-3x"></i>
                                    </div>
                                    <div class="col-lg-5 col-8">
                                        <p class="card-text h3"><?php echo e(($total_cash_payment+$installment_paid)-$total_cash_debit); ?></p>
                                        <h6 class="card-title text-muted">Remaining Cash Amount</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>                    
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="container-fluid bg-white">
        <br>
        <div class="row">
            <div class="col-xd-12 col-sm-8 ">
                <h2>Petty Cash Lists</h2><br>
            </div> 
            <div class="col-xd-12 col-sm-4">
                <a class="btn btn-inverse btn-outline-primary" href="/debit_amount">Debit Cash</a>
            </div>
            <div>
                <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
            </div>
        </div>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Debit From</th>
                    <th scope="col">Debit Amount</th>
                    <th scope="col">Remaining Amount</th>
                    <th scope="col">Debit Date</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $count = 1;?>
                  <?php $__currentLoopData = $pettys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $petty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($count); ?></td>
                    <td><?php echo e($petty['taken_from']); ?></td>
                    <td><?php echo e($petty['taken_amount']); ?></td>
                    <td><?php echo e($petty['remaining_amount']); ?></td>
                    <td>
                        <?php echo e($petty['created_at']); ?>

                    </td>
                  </tr>
                  <?php $count = $count+1; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($pettys->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/petty/list.blade.php ENDPATH**/ ?>