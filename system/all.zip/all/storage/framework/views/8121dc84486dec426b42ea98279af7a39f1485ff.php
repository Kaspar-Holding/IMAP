<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script src="<?php echo e(asset('js/jQuery.print.js')); ?>" defer></script>
	<script type="text/javascript">
		$(document).ready(function(){
            $.print("#printable");
        });
	</script>
	<br>
	<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $carDetail          = \App\Models\Cars::where('id',$sale['car_id'])->first();
        $installmentDetail  = \App\Models\Installments::where('car_id',$sale['car_id'])->get();
        $installmentDetails = \App\Models\Installments::where('car_id',$sale['car_id'])->first();
        $installmentPaid    = \App\Models\Installments::where('car_id',$sale['car_id'])->where('status','1')->count();
        $installmentPending = \App\Models\Installments::where('car_id',$sale['car_id'])->where('status','0')->count();
        $paidAmount         = \App\Models\Installments::where('car_id',$sale['car_id'])->where('status','1')->sum('installments.installment_price');
    ?>
    <?php if($installmentPaid == $sale['total_installments']): ?>
        <?php
            $status        = \App\Models\Sale::where('car_id',$sale['car_id'])->update(
                        [
                            'status'=>1,
                        ]);
        ?>
    <?php endif; ?>
	<div class="invoice-box" id="printable">
		<table>
			<tr class="top">
				<td colspan="2">
					<table>
						<tr>
							<td class="title text-center">
								Sale Details
							</td>

						</tr>
					</table>
				</td>
			</tr>

			<tr class="information">
				<td colspan="2">
					<table>
						<tr>
							<td>
								<b>Customer Detail:</b><br />
								<?php echo e($sale['customer_name']); ?><br />
								<?php echo e($sale['customer_phone']); ?><br />
								<?php echo e($sale['customer_address']); ?>

							</td>

							<td>
								<b>Payment Detail:</b><br />
								<small><b>Payment Method:</b></small>  
								<?php if($sale['payment_method'] == "full_payment"): ?>
			                        Full Payment
			                    <?php else: ?>
			                        Installments
			                    <?php endif; ?><br />
								<small><b>Sale Price:</b></small> <?php echo e($carDetail->sale_amount); ?><br />
								<?php if($sale['payment_method'] == "installments"): ?>
								<small><b>Down Payment:</b></small> <?php echo e($carDetail->sale_amount); ?><br />
								<small><b>Remaining Amount:</b></small> <?php echo e($installmentDetails->remaining_payment-$paidAmount); ?><br />
								<?php endif; ?>
							</td>
						</tr>
					</table>
				</td>
			</tr>

			<!-- <tr class="information">
				<td><b>Car Details:</b></td>
			</tr>
			<tr class="heading">
				<td>Car Method</td>

				<td>Check #</td>
			</tr>

			<tr class="details">
				<td>Check</td>

				<td>1000</td>
			</tr>

			<tr class="heading">
				<td>Item</td>

				<td>Price</td>
			</tr>

			<tr class="item">
				<td>Website design</td>

				<td>$300.00</td>
			</tr>

			<tr class="item">
				<td>Hosting (3 months)</td>

				<td>$75.00</td>
			</tr>

			<tr class="item last">
				<td>Domain name (1 year)</td>

				<td>$10.00</td>
			</tr>

			<tr class="total">
				<td></td>

				<td>Total: $385.00</td>
			</tr> -->
		</table>
		<h5>Car Details</h5>
		<div class="table-responsive">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">Car Name</th>
                    <th scope="col">Purchase Date</th>
                    <th scope="col">Chassis Number</th>
                    <th scope="col">Model</th>
                    <th scope="col">Colour</th>
                    <th scope="col">Engine</th>
                  </tr>
                </thead>
                <tbody>
                	<tr>
	                	<td class="text-center"><?php echo e($carDetail->car_name); ?></td>
	                    <td class="text-center"><?php echo e($carDetail->date); ?></td>
	                    <td class="text-center"><?php echo e($carDetail->chassis_number); ?></td>
	                    <td class="text-center"><?php echo e($carDetail->model); ?></td>
	                    <td class="text-center"><?php echo e($carDetail->colour); ?></td>
	                    <td class="text-center"><?php echo e($carDetail->engine); ?></td>
	                </tr>
                </tbody>
            </table>
        </div>
		<div class="table-responsive">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">Installment No</th>
                    <th scope="col">Installment Price</th>
                    <th scope="col">Due Date</th>
                    <th scope="col">Paid Date</th>
                    <th scope="col">Status</th>
                  </tr>
                </thead>
                <tbody>
                <?php $count = 1; ?>
                  <?php $__currentLoopData = $installmentDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-center"><?php echo e($count); ?></td>
                    <td class="text-center"><?php echo e($installment->installment_price); ?></td>
                    
                    <td class="text-center"><?php echo e($installment->latest_installment_date); ?></td>
                    <td class="text-center">
                        <?php if($installment->status == 1): ?>
                            <?php echo e($installment->updated_at); ?>

                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <?php if($installment->status == 0): ?>
                            Pending
                        <?php else: ?>
                            Paid
                        <?php endif; ?>
                    </td>
                  </tr>
                  <?php $count++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/sale/print.blade.php ENDPATH**/ ?>