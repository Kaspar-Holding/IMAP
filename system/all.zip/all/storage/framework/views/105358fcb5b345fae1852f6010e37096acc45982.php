<button <?php echo e($attributes->merge(['type' => 'button', 'class' => 'btn btn-danger text-white text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/jynxcujg/public_html/system/resources/views/vendor/jetstream/components/danger-button.blade.php ENDPATH**/ ?>