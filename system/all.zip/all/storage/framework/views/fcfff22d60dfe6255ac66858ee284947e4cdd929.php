
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    <div class="container bg-white">
        <br><br>
        <div class="d-flex justify-content-center">
            <h2>Add New Car</h2>
        </div>

        <form class="container" action="/add_new_car" method="POST">
            <?php echo csrf_field(); ?>
            <div>
                <br>
                <label class="form-label">Car Key</label>
                <input type="text" name="car_key" class="form-control" >
                <div class="form-text">Please Enter the Unique Car Key</div>
            </div>
            <div>
                <br>
                <label class="form-label">Car Chassis Number</label>
                <input type="text" name="chassis_number" class="form-control" >
                <div class="form-text">Please Enter the Unique Car Chassis Number</div>
            </div>
            <div>
                <br>
                <label class="form-label">Car Model</label>
                <input type="text" name="model" class="form-control" >
                <div class="form-text">Please Enter the Car Model</div>
            </div>
            <div>
                <br>
                <label class="form-label">Car Colour</label>
                <input type="text" name="colour" class="form-control" >
                <div class="form-text">Please Enter the Car Colour</div>
            </div>
            <div>
                <br>
                <label class="form-label">Car Engine Size</label>
                <input type="text" name="engine" class="form-control" >
                <div class="form-text">Please Enter the Car Engine Size</div>
            </div>
            <div>
                <br>
                <label class="form-label">Japanese Price</label>
                <input type="text" name="japanese_price" class="form-control" >
                <div class="form-text">Please Enter the Japanese Price of the Car</div>
            </div>
            <br>
            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-primary link-light col-sm-4">ADD</button>
            </div>
            
          </form>
    </div>


    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\KASPAR PROJECTS\Web App for Botswana\resources\views/add-new-car.blade.php ENDPATH**/ ?>