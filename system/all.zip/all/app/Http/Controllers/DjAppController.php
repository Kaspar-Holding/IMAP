<?php

namespace App\Http\Controllers;

use App\Models\DjUser;
use App\Models\Genre;
use App\Models\DjAgreement;
use App\Models\EventReject;
use App\Models\Event;
use App\Models\Booking;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Carbon\Carbon;
use DB;


class DjAppController extends Controller
{
    function register_djuser(Request $req) {
        $type = "application/json";
        $result = json_decode(file_get_contents("php://input"), true);
        $djusers = DjUser::where('email','=',$result['email'])->get();
        $phone_check = DjUser::where('phone_number','=',$result['phone_number'])->get();
        if (sizeof($djusers) > 0 && sizeof($phone_check) > 0){
          return response()->json(["message" => "Email or Phone Number already exists!", "status" => "2"], 404);
        }else{
          
          
          
          if ($result['password'] == $result['c_password']) {
             
              $djusers = new DjUser;
              $djusers->first_name       = $result['first_name'];
              $djusers->last_name        = $result['last_name'];
              $djusers->email            = $result['email'];
              $djusers->password         = Hash::make($result['password']);
              $djusers->phone_number     = $result['phone_number'];
              $djusers->music_genre     = $result['music_genre'];
              $djusers->gender           = $result['gender'];
              $djusers->representation           = $result['representation'] ;
              $djusers->save();
              $lastId = $djusers->id;  
                
            return response()->json(["message" => "User Registered Successfully", "status" => "1",'id' => $lastId],200);
          }else{
            return response()->json(["message" => "Passwords Didn't Matched", "status" => "0"], 404);
          }
        }
    }
    function login_djuser(Request $req) {
      $type = "application/json";
      $result = json_decode(file_get_contents("php://input"), true);
      $email_login = DjUser::where('email','=',$result['phone_number'])->first();
      if(!empty($email_login)){
        $user_id = $email_login->id;
        if(!$email_login || !Hash::check($result['password'],$email_login->password)){
          return response([
            'error'=>["Email or password is not matched"]
          ]);
        }
      }
      
      if(empty($email_login)){
        
        $phone_login = DjUser::where('phone_number','=',$result['phone_number'])->first();
        $user_id = $phone_login->id;
        if(!$phone_login || !Hash::check($result['password'],$phone_login->password)){
          return response([
            'error'=>["Phone Number or password is not matched"]
          ]);
        }
      }
      

      return response()->json(["message" => "User logged in Successfully", "status" => "1","id"=>$user_id],201);
  }
  public function dj_agreement_status_on(Request $req){
    $type = "application/json";
    $result = json_decode(file_get_contents("php://input"), true);
    DjUser::where('id','=',$result['id'])->update(['agreement_status'=>$result['agreement_status'],
    ]);
      return response()->json(["message" => "Agreement Status Updated Successfully"], 201);
  }
  public function mobile_push_notification($message='', $player_id=''){
		/* SEND NOTIFICATION */
		$content = array(
			"en" => $message
			);
		$fields = array(
			'app_id' => "346d914e-58bb-407c-875e-e9202378bf8a",
			// 'app_id' => "9b212888-74e1-4626-b188-732bcd1f897b",
			'include_player_ids' => array($player_id),
			'data' => array("noti_type" => "order_update"),
			'contents' => $content
		);
		
		$fields = json_encode($fields);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
		curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json; charset=utf-8'));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);

		$response = curl_exec($ch);
		curl_close($ch);
		
		$return["allresponses"] = $response;
		$return = json_encode($return);
		/* SEND NOTIFICATION */
		if(!empty($return)){
			return true;
		}
	}
  public function register_device(Request $req){
    $type = "application/json";
    $result = json_decode(file_get_contents("php://input"), true);
    DjUser::where('id','=',$result['id'])->update(['device_id'=>$result['device_id'],
    ]);
      return response()->json(["message" => "Device Registered Successfully"], 201);
  }
    function music_genre() {
      $type = "application/json";
        
      $music_genre = Genre::select('id','music_genre')->get(); 
      
      return response()->json(['genre_list' =>$music_genre, 'status' => "1"], 200);
  }
  function dj_agreement_status_check() {
    $type = "application/json";
    $result = json_decode(file_get_contents("php://input"), true);
    
    $dj_user = DjUser::where('id','=',$result['id'])->first();
    $dj_agreement_status = $dj_user->agreement_status;
    return response()->json(["agreement_status" => $dj_agreement_status, 'status' => "1"], 200);
  }
  function dj_agreement() {
    $type = "application/json";
      
    $dj_agreement = DjAgreement::select('agreement')->get();
    return response()->json(['agreement' =>$dj_agreement, 'status' => "1"], 200);
  }
  function dj_event_list_api(Request $req){
    $type = "application/json";
    $result = json_decode(file_get_contents("php://input"), true);
    $event_reject = EventReject::select('event_id')->where('dj_id','=',$result['id'])->get();
    $events = Event::select(DB::raw("events.* ,DATE_FORMAT(events.event_date, '%d') as event_date_daY, DATE_FORMAT(events.event_date, '%b') as event_date_month"),)
            ->whereNotIn('events.id',$event_reject->pluck('event_id'))
            ->where('events.dj_id','=',$result['id'])
            ->get();
    return response()->json(['event_list' =>$events ,
                            //  'event_reject'=> $event_reject, 
                             'success' => true], 200);
  }
  
  function register_new_djuser(){
    return view("users.register_djuser");
  }
  public function delete_djadmin_details ($id) {
    if(DjUser::where('id', $id)->exists()) {
       $user= DjUser::where('id', $id)->delete();
       return redirect('/admin_djlist')->with('success','DJ User Deleted Successfully!');
    } else {
       return redirect('/admin_djlist')->with('error','Dj User Not Found');
    }
  }
  public function edit_djadmin_details($id){
    $users_data = DjUser::find($id);
    return view("users.djadminEdit",['user'=>$users_data,]);
  }
  function update_djadmin_user(Request $req){
    $validator = \Validator::make($req->all(), [
      'first_name'   => 'required|string|max:191',
      'last_name'    => 'required|string|max:191',
      'phone_number' => 'required|numeric',
      'email'        => 'required|email',
    ]);
    $users = DjUser::find($req->id);
    $users->first_name       = $req->first_name;
    $users->last_name       = $req->last_name;
    $users->email      = $req->user_email;
    $users->phone_number       = $req->phone_number;
    if(!empty($req->user_password)){
        $users->password   = Hash::make($req->user_password);
    }
    $users->save();
    return redirect('/admin_djlist')->with('success',' Dj User Updated Successfully!');
}
  function save_djuser(Request $req){
    $djusers = DjUser::where('email','=',$req->email)->get();
    if (sizeof($djusers) > 0){
      return redirect('/admin_djlist')->with('error','Email already exists!');
    }else{
      $validator = \Validator::make($req->all(), [
        'first_name'   => 'required|string|max:191',
        'last_name'    => 'required|string|max:191',
        'phone_number' => 'required|numeric',
        'email'        => 'required|email',
        'password'     => 'required',
      ]);
      if ($validator->fails()) {
        $responseArr['message'] = $validator->errors();
        return response()->json($responseArr);
      }
      $djusers = new DjUser;
      $djusers->first_name       = $req->first_name;
      $djusers->last_name        = $req->last_name;
      $djusers->email            = $req->email;
      $djusers->password         = Hash::make($req->password);
      $djusers->phone_number     = $req->phone_number;
      $djusers->music_genre      = $req->music_genre;
      $djusers->gender           = $req->gender;
      $djusers->representation      = $req->representation;
      // if ($req->hasFile('picture')) {
      //     $djusersPic             = time().'.'.$req->picture->extension();
      //     $req->picture->move('image', $djusersPic);
      //     $djusers->picture = $djusersPic;
      // }
      $djusers->save();
      return redirect('/admin_djlist')->with('success','DJ User Registered Successfully!');
    }
  }
  public function admin_djlist(){
    $dj_data = DjUser::all();
    return view("users.admindjlist",['dj_list'=>$dj_data,]);
  }
  public function dj_event_attend_list(){
    $event = Event::all();
    $bookings = DjEventStatus::all();
    return view("event.dj_event_attend_list",['event_list'=>$event,'bookings_list'=>$bookings,]);
  }
  public function update_password(Request $req){
    $type = "application/json";
    $result = json_decode(file_get_contents("php://input"), true);
    $email_login = DjUser::where('email','=',$result['phone_number'])->first();
      if(!empty($email_login)){
        $user_id = $email_login->id;
        DjUser::where('email','=',$result['phone_number'])->update([
          'password'=>Hash::make($result['password']),
        ]);
        return response()->json(["message" => "Password Updated Successfully","id" => $user_id], 200);
      }


      
      else if(empty($email_login)){
        
        $phone_login = DjUser::where('phone_number','=',$result['phone_number'])->first();
        if(!empty($phone_login)){
          $user_id = $phone_login->id;
          DjUser::where('phone_number','=',$result['phone_number'])->update([
            'password'=>Hash::make($result['password']),
          ]);
          return response()->json(["message" => "Password Updated Successfully",'id' => $user_id], 200);
        }
        else{
          return response()->json(["message" => "Phone Number doesn't exist"], 200);
        }
      }
      else{
        return response()->json(["message" => "Email doesn't exist"], 200);
      }
    
      
  }
  public function accept_event(Request $req){
    $type = "application/json";
    $result = json_decode(file_get_contents("php://input"), true);

    Event::where('id','=',$result['event_id'])->update([
      'going_status'=>1, 'dj_id'=>$result['dj_id']
    ]);
    $bookings = new Booking;
      $bookings->dj_id       = $result['dj_id'];
      $bookings->event_id = $result['event_id'];
      $bookings->booking_id = str::random(20);
      $bookings->booking_type        = "4";
      $bookings->save();
      return response()->json(["message" => "Event Accepted"], 200);
  }
  public function reject_event(Request $req){
    $type = "application/json";
    $result = json_decode(file_get_contents("php://input"), true);    
         
          $djusers = new EventReject;
          $djusers->event_id      = $result['event_id'];
          $djusers->dj_id        = $result['dj_id'];
          $djusers->save(); 

    Event::where('id','=',$result['event_id'])->update(['going_status'=>0,'dj_id'=>NULL,
        ]);           
        return response()->json(["message" => "Event Rejected"],200);
  }
  function gallery_event_list(Request $req){
    $type = "application/json";
    $result = json_decode(file_get_contents("php://input"), true);
    $reject_event = EventReject::where('dj_id', '=' ,$result['id'])->first();
    $dt = Carbon::now()->toDateString();
    $events = DB::table('events')
            ->select('events.*',DB::raw("DATE_FORMAT(events.event_date, '%d') as event_date_daY, DATE_FORMAT(events.event_date, '%b') as event_date_month"),)
            ->where('event_date', '<=', $dt)
            ->orWhere('dj_id','=',$result['id'])
            ->get();
    return response()->json(['event_list' =>$events ,'success' => true], 200);
  }
  function gallery_event_images(Request $req){
    $type = "application/json";
    $result = json_decode(file_get_contents("php://input"), true);
    $gallery_images = DB::table('gallery')
            ->join('gallery_images', 'gallery.unique_id', '=', 'gallery_images.gallery_id')
            ->select('gallery_images.*',)
            ->where('gallery.event_id', '=', $result['event_id'])
            ->get();
    return response()->json(['gallery_images' =>$gallery_images ,'success' => true], 200);
  }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DjUser  $DjUser
     * @return \Illuminate\Http\Response
     */
    public function show(DjUser $DjUser)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DjUser  $DjUser
     * @return \Illuminate\Http\Response
     */
    public function edit(DjUser $DjUser)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DjUser  $DjUser
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DjUser $DjUser)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DjUser  $DjUser
     * @return \Illuminate\Http\Response
     */
    public function destroy(DjUser $DjUser)
    {
        //
    }
}
