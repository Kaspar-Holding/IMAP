<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DjAgreement extends Model
{
    use HasFactory;
    protected $table = 'dj_agreements';
}
