
<?php $__env->startSection('pageTitle','In-Active Users'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
               <div class="page_title">
                  <h2>In-Active Users Lists</h2>
               </div>
            </div>
        </div>
         <!-- row -->
        <div class="row">
            <!-- table section -->
            <div class="col-md-12">
               <div class="white_shd full margin_bottom_30">
                  <div class="full graph_head">
                     <div class="heading1 margin_0">
                        
                     </div>
                  </div>
                  <div class="table_section padding_infor_info">
                     <div class="table-responsive-sm">
                        <table class="table table-striped">
                           <thead>
                              <tr>
                                 <th>#</th>
                                 <th>User ID</th>
                                 <th>First name</th>
                                 <th>Last name</th>
                                 <th>Email</th>
                                 <th>Status</th>
                                 <th>Action</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php if(!empty($users_list)): ?>
                              <?php $count = 1;?>
                              <?php $__currentLoopData = $users_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td class="text-capitalize"><?php echo e($count); ?></td>
                                <td class="text-capitalize"><?php echo e($user['user_id']); ?></td>
                                <td class="text-capitalize"><?php echo e($user['first_name']); ?></td>
                                <td class="text-capitalize"><?php echo e($user['last_name']); ?></td>
                                <td class="text-capitalize"><?php echo e($user['email']); ?></td>
                                <td class="text-capitalize"><?php echo e($user['user_status']); ?></td>
                               
                                <td>
                                    <a href="/view_user_details/<?php echo e($user['user_id']); ?>" class="btn btn-sm btn-inverse btn-outline-primary">
                                      Approve  
                                    </a>
                                   
                                </td>
                              </tr>
                              
                              <?php $count = $count+1;?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                              <tr>
                                <th>No User Found</th>
                              </tr>
                              <?php endif; ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jynxcujg/public_html/system/resources/views/users/inactivelist.blade.php ENDPATH**/ ?>