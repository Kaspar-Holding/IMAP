
<?php $__env->startSection('pageTitle','Total Points Redeemed'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
               <div class="page_title">
                  <h2>Points Reedemed</h2>
               </div>
            </div>
        </div>
         <!-- row -->
        <div class="row">
            <!-- table section -->
            <div class="col-md-12">
               <div class="white_shd full margin_bottom_30">
                  <div class="full graph_head">
                     <div class="heading1 margin_0">
                        
                     </div>
                  </div>
                  <div class="table_section padding_infor_info">
                     <div class="table-responsive-sm">
                        <table class="table table-striped">
                           <thead>
                              <tr>
                                 <th>#</th>
                                 <th>User Name</th>
                                 <th>Item ID</th>
                                 <th>Item Type</th>
                                 <th>Points Redeemed</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php if(!empty($points)): ?>
                              <?php $count = 1;?>
                              <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $points): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php
                                    $point = \App\Models\purchase::where('user_id',$points['user_id'])->first();
                                    $user = \App\Models\user_infos::where('user_id',$points['user_id'])->first();
                                ?>
                                <?php if($user): ?>
                              <tr>
                                <td class="text-capitalize"><?php echo e($count); ?></td>
                                <td class="text-capitalize"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></td>
                                <td class="text-capitalize"><?php echo e($points['item_id']); ?></td>
                                <td class="text-capitalize"><?php echo e($points['item_type']); ?></td>
                                <td class="text-capitalize"><?php echo e($points['item_price']); ?></td>
                              </tr>
                               <?php endif; ?>
                              <?php $count = $count+1;?>
                              
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                              <tr>
                                <th>No points collected</th>
                              </tr>
                              <?php endif; ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jynxcujg/public_html/system/resources/views/users/total_points_redeemed.blade.php ENDPATH**/ ?>