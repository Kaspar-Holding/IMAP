<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    

    <div name="container"><br>
        <div class="card">
            <div class="card-header h6 bg-dark" style="color:white">
                <i class="far fa-clipboard"></i>    Filters
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="row">
                            <div class="col-sm-6 col-12">
                                <div class="input-group flex-nowrap">
                                    <span class="input-group-text" id="addon-wrapping"><i class="far fa-box-alt"></i></span>
                                    <input type="text" class="form-control col-sm-3" placeholder="Container" aria-label="From Date" aria-describedby="addon-wrapping">
                                </div>
                            </div>
                            <div class="col-sm-6 col-12">
                                <div class="input-group flex-nowrap">
                                    <span class="input-group-text" id="addon-wrapping"><i class="fas fa-car-alt"></i></span>
                                    <input type="text" class="form-control col-sm-3" placeholder="Car Key" aria-label="From Date" aria-describedby="addon-wrapping">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="row">
                            <div class="col-sm-5 col-12">
                                <div class="input-group flex-nowrap">
                                    <span class="input-group-text" id="addon-wrapping"><i class="far fa-calendar-alt"></i></span>
                                    <input type="date" class="form-control col-sm-3" value="<?php echo e(Carbon\Carbon::parse($first_date->date)->format('Y-m-d')); ?>" placeholder="From Date" aria-label="From Date" aria-describedby="addon-wrapping">
                                </div>
                            </div>
                            <div class="col-sm-5 col-12">
                                <div class="input-group flex-nowrap">
                                    <span class="input-group-text" id="addon-wrapping"><i class="far fa-calendar-alt"></i></span>
                                    <input type="date" class="form-control col-sm-3" value="<?php echo e(Carbon\Carbon::now()->format('Y-m-d')); ?>" placeholder="To Date" aria-label="To Date" aria-describedby="addon-wrapping">
                                </div>
                            </div>
                            <div class="col-sm-2 col-12">
                                <button class="btn btn-inverse btn-outline-primary">GO</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          </div>
          <br>
        <div class="card">
            <div class="card-header h6 bg-dark" style="color:white">
                <i class="far fa-chart-bar"></i>    Inventory
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-cars fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-text h3"><?php echo e($cars_count); ?></p>
                                        <h6 class="card-title text-muted">Cars bought</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-shipping-fast fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-text h3"><?php echo e($cars_sold); ?></p>
                                        <h6 class="card-title text-muted">Sold Cars</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-cars fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-text h3"><?php echo e($cars_count); ?></p>
                                        <h6 class="card-title text-muted">Available Cars</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-box fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-text h3"><?php echo e($containers_count); ?></p>
                                        <h6 class="card-title text-muted">Containers</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
          </div>
          <br>
        
        <div class="card">
            <div class="card-header h6 bg-dark" style="color:white">
                <i class="far fa-bell"></i>    Sales and Orders
            </div>
            <div class="card-body border-bottom border-secondary border-2">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-cash-register fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-text h3"><?php echo e($cars_count); ?></p>
                                        <h6 class="card-title text-muted">Total Expenditures</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-yen-sign fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-text h3">¥ <?php echo e($japanese_price); ?></p>
                                        <h6 class="card-title text-muted">Japanese Price</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-ship fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-text h3">$ <?php echo e($shipment_cost); ?></p>
                                        <h6 class="card-title text-muted">Shipment Cost</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-comment-dollar fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-text h3"><?php echo e($duty_n_vat); ?></p>
                                        <h6 class="card-title text-muted">Duty and V.A.T.</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-car-crash fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-text h3"><?php echo e($repairs); ?></p>
                                        <h6 class="card-title text-muted">Repair Expenditures</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-shipping-fast fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-title h3">0</p>
                                        <h6 class="card-text text-muted">Selling Amount</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body card_custom" id="left">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-cars fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-title h3">0</p>
                                        <h6 class="card-text text-muted">Installments Cars</h6>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-sm-6">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm-4 col-4">
                                        <i class="far fa-file-invoice-dollar fa-3x"></i>
                                    </div>
                                    <div class="col-sm-8 col-8">
                                        <p class="card-title h3">0</p>
                                        <h6 class="card-text text-muted">Pending Installments</h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
          </div>
          <br>
        
        

    




    



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\KASPAR PROJECTS\Web App for Botswana\resources\views/dashboard.blade.php ENDPATH**/ ?>