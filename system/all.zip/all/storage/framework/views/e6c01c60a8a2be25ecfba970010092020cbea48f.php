
<?php $__env->startSection('pageTitle','User Detail'); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
               <div class="page_title">
                  <h2>User Details</h2>
               </div>
            </div>
        </div>
         <!-- row -->
        <div class="row p-3">
            <!-- table section -->
            <div class="col-md-12">
               <div class="white_shd full margin_bottom_30">
                    <div class="full graph_head">
                         <div class="heading1 margin_0">
                            <h2><?php echo e($user['first_name']); ?> <?php echo e($user['last_name']); ?> Details</h2>
                         </div>
                    </div>
        
                    <form class="container-fluid" action="/user_status_update" method="post">
                        <?php echo csrf_field(); ?>
                        <div>
                            <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                        <div class="row p-3">
                            <div class="col-6">
                                <h5>First Name:</h5>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e($user['first_name']); ?></h5>
                            </div>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <h5>Last Name:</h5>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e($user['last_name']); ?></h5>
                            </div>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <h5>Email:</h5>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e($user['email']); ?></h5>
                            </div>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <h5>Phone Number:</h5>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e($user['phone_number']); ?></h5>
                            </div>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <h5>Identification Type:</h5>
                            </div>
                            <div class="col-6">
                                <?php if( $user->identification_type == 1): ?>
                                    <h5>South African ID</h5>                            
                                <?php else: ?>
                                    <h5>Passport</h5>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <h5>Identification Number:</h5>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e($user['identification_num']); ?></h5>
                            </div>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <h5>Gender:</h5>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e($user->gender); ?></h5>
                                
                            </div>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <h5>Date of Birth:</h5>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e($user->dob); ?></h5>
                                
                            </div>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <h5>Nationality:</h5>
                            </div>
                            <div class="col-6">
                                <h5><?php echo e($user->nationality); ?></h5>
                                
                            </div>
                        </div>
                        <div class="row p-3">
                            <div class="col-6">
                                <h5>User Status:</h5>
                            </div>
                            <div class="col-6">
                                <?php if($user['user_status'] == "0"): ?>
                                    <h5>New Registration</h5>
                                <?php elseif($user['user_status'] == "1"): ?>
                                    <h5>Active</h5>
                                <?php elseif($user['user_status'] == "2"): ?>
                                    <h5>Denied</h5>
                                <?php elseif($user['user_status'] == "-1"): ?>
                                    <h5>Blocked</h5>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                        <hr>
                        <?php if( $user->identification_type == 1): ?>
                            <div class="full graph_head">
                                <div class="heading1 margin_0">
                                    <h2>DHA Detail</h2>
                                </div>
                            </div>               
                            <?php if(($dha_profile)): ?>
                                <?php if($dha_profile->dha_api_status == -1): ?>
                                    <div class="row p-3">
                                        <div class="col-6">
                                            <h5>Status:</h5>
                                        </div>
                                        <div class="col-6">
                                            <h5>Invalid credentials</h5>
                                            
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="row p-3">
                                        <div class="col-6">
                                            <h5>Name:</h5>
                                        </div>
                                        <div class="col-6">
                                            <h5><?php echo e($dha_profile->personName); ?> <?php echo e($dha_profile->personSurname); ?></h5>
                                            
                                        </div>
                                    </div>
                                    <div class="row p-3">
                                        <div class="col-6">
                                            <h5>Gender:</h5>
                                        </div>
                                        <div class="col-6">
                                            <h5><?php echo e($dha_profile->gender); ?></h5>
                                            
                                        </div>
                                    </div>
                                    <div class="row p-3">
                                        <div class="col-6">
                                            <h5>Date of Birth:</h5>
                                        </div>
                                        <div class="col-6">
                                            <h5><?php echo e($dha_profile->dateOfBirth); ?></h5>
                                            
                                        </div>
                                    </div>
                                    <div class="row p-3">
                                        <div class="col-6">
                                            <h5>Status:</h5>
                                        </div>
                                        <div class="col-6">
                                            <h5><?php echo e($dha_profile->aliveStatus); ?></h5>
                                            
                                        </div>
                                    </div>
                                    <div class="row p-3">
                                        <div class="col-6">
                                            <h5>Address:</h5>
                                        </div>
                                        <div class="col-6">
                                            <h5><?php echo e($dha_address->addressLine1); ?>

                                                <?php if(!is_null($dha_address->addressLine2)): ?>
                                                , <?php echo e($dha_address->addressLine2); ?>

                                                <?php endif; ?>
                                                <?php if(!is_null($dha_address->addressLine3)): ?>
                                                , <?php echo e($dha_address->addressLine3); ?>

                                                <?php endif; ?>
                                                <?php if(!is_null($dha_address->addressLine4)): ?>
                                                , <?php echo e($dha_address->addressLine4); ?>

                                                <?php endif; ?>
                                                <?php if(!is_null($dha_address->addressLine5)): ?>
                                                , <?php echo e($dha_address->addressLine5); ?>

                                                <?php endif; ?>
                                            </h5>
                                            
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="row p-3">
                                    <div class="col-12">
                                        <div class="d-flex justify-content-center">
                                            <a href="/fetch_dha_profile/<?php echo e($user->user_id); ?>" type="submit" class="btn btn-primary link-light col-sm-4">Fetch DHA Information</a>
                                        </div>
                                    </div>
                                </div>
                                
                                <hr>
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="d-flex justify-content-center">
                            <a href="/approve_user/<?php echo e($user->user_id); ?>" type="submit" class="btn btn-primary link-light col-sm-4">Approve</a> &nbsp;
                            
                        </div>
                        <br>
                        <div class="d-flex justify-content-center">
                            <a href="/deny_user/<?php echo e($user->user_id); ?>" type="submit" class="btn btn-warning link-light col-sm-4">Deny</a> &nbsp;
                            <a href="/block_user/<?php echo e($user->user_id); ?>" type="submit" class="btn btn-danger link-light col-sm-4">Block</a>
                        </div>
                    </form>
                    <!--<?php if($user->user_status == "0"): ?>-->
                    <!--    <div class="d-flex justify-content-center">-->
                    <!--        <a href="/deny_user/<?php echo e($user->user_id); ?>" type="submit" class="btn btn-warning link-light col-sm-4">Deny</a> &nbsp;-->
                    <!--        <a href="/block_user/<?php echo e($user->user_id); ?>" type="submit" class="btn btn-danger link-light col-sm-4">Block</a>-->
                    <!--    </div>-->
                    <!--<?php endif; ?>-->
                    <br>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jynxcujg/public_html/system/resources/views/users/view.blade.php ENDPATH**/ ?>