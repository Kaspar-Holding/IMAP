
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row column_title">
          <div class="col-md-12">
            <div class="page_title">
              <h2>Edit Question</h2>
            </div>
          </div>
        </div>
         <!-- row -->
        <div class="row">
            <!-- table section -->
          <div class="col-md-12">
            <div class="white_shd full margin_bottom_30">
              <div class="full graph_head">
                <div class="heading1 margin_0">
                  
                </div>
              </div>
              <?php
                $num = 1;
                $answers = json_decode($question->answers);
              ?>
              <form class="container-fluid" action="/update_question" method="POST" style="padding:30px; padding-bottom:40px;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($question->id); ?>">
                <input type="hidden" name="survey_id" value="<?php echo e($question->survey_id); ?>">
                <div>
                  <label class="form-label">Question</label>
                  <input type="text" name="survey_question" class="form-control" value="<?php echo e($question->survey_question); ?>" >
                </div>
                <br>
                <div class="clonedata">
                    <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row abcd">
                      <div class="col-lg-8">
                        <div class="example-1">
                          <label class="form-label">Answer</label>
                          <div class="example-2">
                            <input type="text" name="answers[]" class="form-control checks" value="<?php echo e($ans); ?>">
                            <br>
                          </div>
                        </div>
                      </div>
                      <div class="col-lg-2">
                        <button type="button" class="removemore btn btn-sm btn-inverse btn-outline-danger mt-4">Delete</button>
                      </div>
                    </div>
                        <?php
                        $num++;
                      ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <button type="button" class="addmore btn btn-sm btn-inverse btn-outline-success mb-4">Add More</button>
                    </div>
                </div>
                <div>
                  <label class="form-label">Question Description</label>
                  <textarea class="form-control" name="survey_question_description" rows="4"> <?php echo e($question->survey_question_description); ?></textarea>
                </div>
                <br>
                <div class="row" style="padding-left:30px; padding-top:10px;">
                  <button type="submit" class="btn btn-primary my-button col-md-2 link-light col-sm-4">Update</button>
                </div>
                
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jynxcujg/public_html/system/resources/views/survey/question/edit.blade.php ENDPATH**/ ?>