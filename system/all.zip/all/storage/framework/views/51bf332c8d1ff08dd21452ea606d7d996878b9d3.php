<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
  <br>
    <div class="container bg-white">
        <br>
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <h2>Dollar To Pula Rate</h2><br>
            </div>
        </div>
        <div>
            <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div> 
        <form class="container " action="/edit_rate" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-4">
                    <h5>Rate:</h5>
                </div>
                <div class="col-8">
                    <input type="text" class="form-control h5" name="rate" value="<?php echo e($rate['pulla_rate']); ?>" id="">
                    <input type="hidden" name="id" value="<?php echo e($rate['id']); ?>">
                </div>
            </div>
            <br>
            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-primary link-light col-sm-4">Update</button>
            </div>
            <br>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/dollar_to_pula.blade.php ENDPATH**/ ?>