<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="img/logo/logo.png" rel="icon">
  <title><?php echo e(config('app.name', 'Laravel')); ?></title>
  <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <!-- <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css"> -->
  <link href="<?php echo e(asset('new/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
  <link href="<?php echo e(asset('new/css/ruang-admin.min.css')); ?>" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ajaxy/1.6.1/scripts/jquery.ajaxy.min.js" defer></script>
        
        <style>
            @media (max-width: 768px) {
                div {
                    border-right: 0px;
                }
            }
          .bd-placeholder-img {
              font-size: 1.125rem;
              text-anchor: middle;
              -webkit-user-select: none;
              -moz-user-select: none;
              user-select: none;
          }
  
          @media  only screen and (min-width: 768px) {
                .bd-placeholder-img-lg {
                    font-size: 3.5rem;
                }
                .card_custom {
                    border-right: 2px solid grey;
                }
          }
          @media  only screen and (max-width: 700px) {
                .nav_custom {
                    width: 100%;
                }
                .card_custom {
                    border-right: none;
                }
            }
            .invoice-box {
                max-width: 800px;
                margin: auto;
                padding: 30px;
                border: 1px solid #eee;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
                font-size: 16px;
                line-height: 24px;
                font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
                color: #555;
            }

            .invoice-box table {
                width: 100%;
                line-height: inherit;
                text-align: left;
            }

            .invoice-box table td {
                padding: 5px;
                vertical-align: top;
            }

            .invoice-box table tr td:nth-child(2) {
                text-align: right;
            }

            .invoice-box table tr.top table td {
                padding-bottom: 20px;
            }

            .invoice-box table tr.top table td.title {
                font-size: 45px;
                line-height: 45px;
                color: #333;
            }

            .invoice-box table tr.information table td {
                padding-bottom: 40px;
            }

            .invoice-box table tr.heading td {
                background: #eee;
                border-bottom: 1px solid #ddd;
                font-weight: bold;
            }

            .invoice-box table tr.details td {
                padding-bottom: 20px;
            }

            .invoice-box table tr.item td {
                border-bottom: 1px solid #eee;
            }

            .invoice-box table tr.item.last td {
                border-bottom: none;
            }

            .invoice-box table tr.total td:nth-child(2) {
                border-top: 2px solid #eee;
                font-weight: bold;
            }

            @media  only screen and (max-width: 600px) {
                .invoice-box table tr.top table td {
                    width: 100%;
                    display: block;
                    text-align: center;
                }

                .invoice-box table tr.information table td {
                    width: 100%;
                    display: block;
                    text-align: center;
                }
            }

            /** RTL **/
            .invoice-box.rtl {
                direction: rtl;
                font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
            }

            .invoice-box.rtl table {
                text-align: right;
            }

            .invoice-box.rtl table tr td:nth-child(2) {
                text-align: left;
            }
            .select2-selection--single{
                height: 37px !important;
                background-color: #f8fafc !important;
            }
            .select2-container--default .select2-selection--single .select2-selection__rendered{
                line-height: 35px !important;
            }
        </style>
</head>
    <body id="page-top">
        <div id="wrapper">
            <?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.banner','data' => []]); ?>
<?php $component->withName('jet-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
                <?php echo $__env->yieldContent('content'); ?>
                </div>
                <!-- Footer -->
                <footer class="sticky-footer bg-white">
                    <div class="container my-auto">
                      <div class="copyright text-center my-auto">
                        <span>copyright &copy; <script> document.write(new Date().getFullYear()); </script> - developed by
                          <b><a href="#" target="_blank">Kaspar</a></b>
                        </span>
                      </div>
                    </div>
                </footer>
                <!-- Footer -->    
            </div>
        </div>
            <!-- Scroll to top -->
      <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
      </a>

    <!-- <script src="<?php echo e(asset('new/vendor/jquery/jquery.min.js')); ?>"></script> -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('new/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('new/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('new/js/ruang-admin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('new/vendor/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('new/js/demo/chart-area-demo.js')); ?>"></script>  
    <script src="<?php echo e(asset('new/js/demo/chart-pie-demo.js')); ?>"></script>  
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script type="text/javascript">
        $("#payment_method").change(function(){
            var payment = $("#payment_method").val();
            if (payment=="full_payment") {
                $("#full_payment").show();
                $("#installments").hide();
            }else if(payment=="installments"){
                $("#installments").show();
                $("#full_payment").hide();
            }
        });
        $("#convert").change(function(){
            var change = $("#convert").val();
            if (change=="japanese") {
                var newChange = $("#japanese").val();
                $("#pula_rate").val(newChange);
            }else if(change=="pula"){
                var newChange = $("#pula").val();
                $("#pula_rate").val(newChange);
            }
        });
        $("#debits").change(function(){
            var payment = $("#debits").val();
            console.log(payment);
            if (payment=="cash") {
                var cashed = $("#available_amount_cash").val();
                $("#debit_amount").attr({
                   "max" : cashed,        // substitute your own
                   "min" : 0          // values (or variables) here
                });
                $("#cash").show();
                $("#cheque").hide();
            }else if(payment=="cheque"){
                var cashed = $("#available_amount_cheque").val();
                $("#debit_amount").attr({
                   "max" : cashed,        // substitute your own
                   "min" : 0          // values (or variables) here
                });
                $("#cheque").show();
                $("#cash").hide();
            }
        });
        $("#sale_amount").keyup(function(){
            var saleAmount = parseFloat($("#sale_amount").val());
            var downAmount = parseFloat($("#down_payment").val());
            if (downAmount != '') {
                var minus = saleAmount - downAmount;
                $("#remaining_payment").val(minus);
            }else{
                $("#remaining_payment").val(saleAmount);
            }
        });
        $("#down_payment").keyup(function(){
            var saleAmount = parseFloat($("#sale_amount").val());
            var downAmount = parseFloat($("#down_payment").val());
            var minus = saleAmount - downAmount;
            $("#remaining_payment").val(minus);
        });
        $(document).ready(function() {
            $('.js-example-basic-single').select2();
        });
        $("#records").change(function(){
            var roomsSelected = $('#records option:selected').val();
            var roomsDisplayed = $('[id^="room-"]:visible').length;
            var roomsRendered = $('[id^="room-"]').length;                    
            //if room count is greater than number displayed - add or show accordingly
            if (roomsSelected > roomsDisplayed) {
                for (var i=1;i<=roomsSelected;i++){
                    var r=$('#room-'+i);
                    if (r.length == 0) {
                        var clone=$('#room-1').clone(); //clone
                        clone.attr("id", "newId").find("#searchItems").attr("id", "input_"+i);
                        clone.attr("id", "newId").find("#jp_price").attr("id", "jp_price_"+i);
                        clone.attr("id", "newId").find("#japan_to_durban").attr("id", "japan_to_durban_"+i);
                        clone.attr("id", "newId").find("#jtd_price").attr("id", "jtd_price_"+i);
                        clone.attr("id", "newId").find("#durban_to_botswana").attr("id", "durban_to_botswana_"+i);
                        clone.attr("id", "newId").find("#jtb_price").attr("id", "jtb_price_"+i);
                        clone.attr("id", "newId").find("#repair").attr("id", "repair_"+i);
                        clone.attr("id", "newId").find("#r_price").attr("id", "r_price_"+i);
                        //change ids appropriately
                        console.log(clone);
                        setNewID(clone,i);
                        // clone.children('div').children('select').each(function() {
                        //     setNewID($(this),i);
                        // });
                        $(clone).insertAfter($('#room-'+roomsRendered));
                    }else {
                        //if the room exists and is hidden 
                        $(r).show();
                    }
                }                        
            }
            else {
                //else if less than room count selected - hide
                for (var i=++roomsSelected;i<=roomsRendered;i++){
                    $('#room-'+i).hide();
                }
            }
        });
        function setNewID(elem, i) {
            oldID=elem.attr('id');
            newId=oldID.substring(0,oldID.indexOf('-'))+"-"+i;
            elem.attr('id','room'+newId);
        }
    </script>
    <script type="text/javascript">
        function addToPaid(sw){
          if(sw) {
            var value = sw.id + sw.getAttribute('value');
            console.log(value);
          var token = $("meta[name='csrf-token']").attr("content");
          $.ajax({
            url: "<?php echo e(url('/installment_pay_car')); ?>",
            type: "post",
            data: { id:value , _token: '<?php echo e(csrf_token()); ?>' }, 
            success:function(response) {
                if(response.status === true) {
                    setInterval('location.reload()', 1500);
                }
            }
          }); 
          }
        }
    </script>
    <script src="<?php echo e(asset('js/rate.js')); ?>" defer></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script type="text/javascript">
        function permissionError(){
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'You Have No Permission To Access This Part',
            })
        }
    </script>
</body>
            
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\resources\views/layouts/app.blade.php ENDPATH**/ ?>