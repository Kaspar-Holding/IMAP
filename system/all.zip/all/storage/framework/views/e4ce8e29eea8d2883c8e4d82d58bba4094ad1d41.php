
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container-fluid" id="container-wrapper">
        <br>
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <h2><?php echo e($user['name']); ?> Details</h2><br>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <h5>Name:</h5>
            </div>
            <div class="col-6">
                <h5><?php echo e($user['name']); ?></h5>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-6">
                <h5>Email:</h5>
            </div>
            <div class="col-6">
                <h5><?php echo e($user['email']); ?></h5>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-6">
                <h5>Role:</h5>
            </div>
            <div class="col-6">
                <h5 class="text-capitalize"><?php echo e($user['role']); ?></h5>
            </div>
        </div>
        <br>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/users/view.blade.php ENDPATH**/ ?>