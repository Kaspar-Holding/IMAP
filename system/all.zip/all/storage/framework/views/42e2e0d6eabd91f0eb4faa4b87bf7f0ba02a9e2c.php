
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
  <div class="container-fluid" id="container-wrapper">
      <div class="row">
          <div class="col-xd-12 col-sm-10 ">
              <h2>Manager Permissions</h2><br>
          </div>
          <div>
              <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </div>
      </div>      
      <form class="container-fluid" action="/edit_permissions" method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="id" value="<?php echo e($permissions->id); ?>">
          <table class="table table-striped">
            <thead>
              <tr>
                <th scope="col"></th>
                <th scope="col">Add</th>
                <th scope="col">View</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th>
                  Car Management
                </th>
                <td>
                  <input type="checkbox" class="minimal" name="car_add" id="permission" class="minimal" value="1" <?php if($permissions->car_add == 1): ?> checked <?php endif; ?>>
                </td>
                <td>
                  <input type="checkbox" class="minimal" name="car_show" id="permission" class="minimal" value="1" <?php if($permissions->car_show == 1): ?> checked <?php endif; ?>>
                </td>
                <td>
                  <input type="checkbox" class="minimal" name="car_edit" id="permission" class="minimal" value="1" <?php if($permissions->car_edit == 1): ?> checked <?php endif; ?>>
                </td>
                <td>
                  <input type="checkbox" class="minimal" name="car_delete" id="permission" class="minimal" value="1" <?php if($permissions->car_delete == 1): ?> checked <?php endif; ?>>
                </td>
              </tr>
              <tr>
                <th>
                  Sale Management
                </th>
                <td>
                  <input type="checkbox" class="minimal" name="sale_add" id="permission" class="minimal" value="1" <?php if($permissions->sale_add == 1): ?> checked <?php endif; ?>>
                </td>
                <td>
                  <input type="checkbox" class="minimal" name="sale_show" id="permission" class="minimal" value="1" <?php if($permissions->sale_show == 1): ?> checked <?php endif; ?>>
                </td>
                <td>
                </td>
                <td>
                  <input type="checkbox" class="minimal" name="sale_delete" id="permission" class="minimal" value="1" <?php if($permissions->sale_delete == 1): ?> checked <?php endif; ?>>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="d-flex justify-content-center">
            <button type="submit" class="btn btn-primary link-light col-sm-4">Update</button>
          </div>
          <br>
      </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/users/permissions.blade.php ENDPATH**/ ?>