
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <h2>Car Add Form</h2><br>
                <?php if($errors->any()): ?>
                <h4><?php echo e($errors->first()); ?></h4>
                <?php endif; ?>
            </div>
        </div>
        <form class="container-fluid" action="/add_new_car" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-lg-3">
                    <div>
                        <input type="hidden" name="" id="pula_rate" value="<?php echo e($rate['pulla_rate']); ?>">
                        <label class="form-label">Create Records</label>
                        <select class="form-control" name="records" id="records">
                            <option value="1" selected>1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">17</option>
                            <option value="28">28</option>
                            <option value="29">29</option>
                            <option value="30">30</option>
                            <option value="31">31</option>
                            <option value="32">32</option>
                            <option value="33">33</option>
                            <option value="34">34</option>
                            <option value="35">35</option>
                            <option value="36">36</option>
                            <option value="37">37</option>
                            <option value="38">38</option>
                            <option value="39">39</option>
                            <option value="40">40</option>
                            <option value="41">41</option>
                            <option value="42">42</option>
                            <option value="43">43</option>
                            <option value="44">44</option>
                            <option value="45">45</option>
                            <option value="46">46</option>
                            <option value="47">47</option>
                            <option value="48">48</option>
                            <option value="49">49</option>
                            <option value="50">50</option>
                        </select>
                        <div class="form-text">Please Select the quantity you want to create records</div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div>
                        <label class="form-label">Dollar To Pula</label>
                        <input type="text" name="pula" id="pula" class="form-control">
                    </div>
                </div>
                <div class="col-lg-3">
                    <div>
                        <label class="form-label">Japanese yen to pula</label>
                        <input type="text" name="japanese" id="japanese" class="form-control">
                    </div>
                </div>
                <div class="col-lg-3">
                    <div>
                        <label class="form-label">Convert Into</label>
                        <select class="form-control" name="convert" id="convert">
                            <option>-- Select --</option>
                            <option value="pula">Dollar To Pula</option>
                            <option value="japanese">Japanese yen to pula</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div>
                        <label class="form-label">Freight</label>
                        <input type="number" name="freight" id="freight" class="form-control">
                        <div class="form-text">Please Enter the Total Freight of all Cars</div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div>
                        <label class="form-label">Duty</label>
                        <input type="number" name="duty" class="form-control">
                        <div class="form-text">Please Enter the Total Duty of all Car</div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div>
                        <label class="form-label">V.A.T.</label>
                        <input type="number" name="vat" class="form-control">
                        <div class="form-text">Please Enter V.A.T. Duty Charges of all Car</div>
                    </div>
                </div>
            </div>
            <?php 
              $mytime = Carbon\Carbon::now()->format('Y_m_');
            ?>
            <div class="row">
                <div class="col-lg-12">
                    <div>
                        <label class="form-label">Container Number</label>
                        <div class="input-group mb-3">
                          <span class="input-group-text"><?php echo e($mytime); ?></span>
                          <input type="number" class="form-control" name="container_number" required>
                        </div>
                    </div> 
                </div>
            </div>                                   
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Car Name</th>
                            <th scope="col">Chassis #</th>
                            <th scope="col">Car Key</th>
                            <th scope="col">Model</th>
                            <th scope="col">Colour</th>
                            <th scope="col">Engine</th>
                            <th scope="col">Purchase Date</th>
                            <th scope="col">Japanese Price</th>
                            <th scope="col">Japan To Durban SC</th>
                            <th scope="col">Durban To Botswana SC</th>
                            <th scope="col">Repairs</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr id="room-1">
                            <td>
                                <input style="width:150px;" type="text" name="car_name[]" class="form-control" required >
                            </td>
                            <td>
                                <input style="width:150px;" type="text" name="chassis_number[]" class="form-control">
                            </td>
                            <td>
                                <div style="width:200px;" class="input-group mb-3">
                                  <span class="input-group-text"><?php echo e($mytime); ?></span>
                                  <input type="number" class="form-control" name="car_key[]" required>
                                </div>
                            </td>
                            <td>
                                <input style="width:150px;" type="text" name="model[]" class="form-control">
                            </td>
                             <td>
                                <input style="width:150px;" type="text" name="color[]" class="form-control">
                            </td>
                            <td>
                                <input style="width:150px;" type="text" name="engine[]" class="form-control">
                            </td>
                            <td>
                                <input style="width:150px;" type="date" name="date[]" class="form-control">
                            </td>
                            <td>
                                <input style="width:150px;" type="number" name="japanese_price[]" id="searchItems" class="form-control" required>
                                <div id="jp_price"></div>
                            </td>
                            <td>
                                <input style="width:150px;" type="number" name="japan_to_durban[]" id="japan_to_durban" class="form-control" required>
                                <div id="jtd_price"></div>
                            </td>
                            <td>
                                <input style="width:150px;" type="number" name="durban_to_botswana[]" id="durban_to_botswana" class="form-control" required>
                                <div id="jtb_price"></div>
                            </td>
                            <td>
                                <input style="width:150px;" type="number" name="repair[]" id="repair" class="form-control">
                                <div id="r_price"></div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <br>
            <div class="details"></div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary link-light col-sm-4">Save</button>
            </div>
            <div class="d-flex justify-content-center"></div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/add_new_car.blade.php ENDPATH**/ ?>