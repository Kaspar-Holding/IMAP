
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="card customBorder">
            <div class="card-header h6 bg-custom" style="color:white">
                <i class="far fa-clipboard"></i>    Filters
            </div>
            <form action="/search_sale" method="post">
            <?php echo csrf_field(); ?>
            <div class="card-body">
                <div class="row">
                    <div class="col-sm-5">
                        <div class="row">
                            <div class="col-sm-6 col-12">
                                <div class="input-group customGroup p-2 mb-3 flex-nowrap">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="addon-wrapping"><i class="far fa-cars"></i></span>
                                    </div>
                                    <select name="car_id" class="form-control">
                                        <option value="">-- Select --</option>
                                        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($car->id); ?>" <?php if(request()->get('car_id') == $car->id): ?> selected <?php endif; ?>><?php echo e($car->car_name); ?> <?php echo e($car->model); ?> <?php echo e($car->chassis_number); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-6 col-12">
                                <div class="input-group flex-nowrap">
                                    <span class="input-group-text" id="addon-wrapping"><i class="fas fa-money-bill-alt"></i></span>
                                    <select name="payment_method" class="form-control">
                                        <option value="">-- Select --</option>
                                        <option value="full_payment" <?php if(request()->get('payment_method') == "full_payment"): ?> selected <?php endif; ?>>Full Payment</option>
                                        <option value="installments" <?php if(request()->get('payment_method') == "installments"): ?> selected <?php endif; ?>>Installments</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="row">
                            <div class="col-sm-5 col-12">
                                <div class="input-group flex-nowrap">
                                    <span class="input-group-text" id="addon-wrapping"><i class="fas fa-tasks"></i></span>
                                    <select name="status_id" class="form-control">
                                        <option value="">-- Select --</option>
                                        <option value="1"  <?php if(request()->get('status_id') == '1'): ?> selected <?php endif; ?>>Completed</option>
                                        <option value="0"  <?php if(request()->get('status_id') == '0'): ?> selected <?php endif; ?>>Pending</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-5 col-12">
                                <div class="input-group flex-nowrap">
                                    <span class="input-group-text" id="addon-wrapping"><i class="far fa-calendar-alt"></i></span>
                                    <input type="date" class="form-control" value="<?php echo e(request()->get('selling_date')); ?>" placeholder="Date" name="selling_date" aria-label="From Date" aria-describedby="addon-wrapping">
                                </div>
                            </div>
                            <div class="col-sm-2 col-12">
                                <button type="submit" class="btn btn-inverse btn-outline-primary">GO</button>
                                <?php if($get_car_id_value !=null || $get_payment_method_value!=null || $get_status_value!=null || $get_selling_date_value!=null): ?>
                                    <a class="btn btn-primary btn-sm mt-2 text-white" href="<?php echo e(route('sales_management')); ?>">Reset</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </form>
        </div>
        <br>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-xd-12 col-sm-10 ">
                        <h2>Sales Records</h2><br>
                    </div>
                    <div class="col-xd-12 col-sm-2">
                        <a class="btn btn-inverse btn-outline-primary" href="<?php echo e(route('sell_car')); ?>">Sell a Car</a>
                    </div>
                    <div>
                        <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <?php
                    $day = Carbon\Carbon::now()->format('d');
                    if ($day == 1){
                        echo "True";
                    }
                ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Container #</th>
                            <th scope="col">Car Key</th>
                            <th scope="col">Car Name</th>
                            <th scope="col">Total Price</th>
                            <th scope="col">Sale Price</th>
                            <th scope="col">Payment Method</th>
                            <th scope="col">Status</th>
                            <th scope="col">Sell Date</th>
                            <th scope="col">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $count = 1; ?>
                          <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $carDetail = \App\Models\Cars::where('id',$sale['car_id'])->first();
                            ?>
                          <tr>
                            <td><?php echo e($count); ?></td>
                            <td><?php echo e($carDetail->container_number); ?></td>
                            <td><?php echo e(str_replace('-',"_",substr($carDetail->created_at,0,7)) . '_' . $carDetail->id); ?></td>
                            <td><?php echo e($carDetail->car_name); ?></td>
                            
                            <td><?php echo e($carDetail->japanese_price+$carDetail->japan_to_durban_price+$carDetail->durban_to_botswana+$carDetail->repair_charges+$carDetail->duty+$carDetail->vat); ?></td>
                            <td><?php echo e($sale['sales_amount']); ?></td>
                            <td>
                                <?php if($sale['payment_method'] == "full_payment"): ?>
                                    Full Payment
                                <?php else: ?>
                                    Installments
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($sale['status'] == 0): ?>
                                    <button type="button" class="btn btn-danger text-white">Pending</button>
                                <?php else: ?>
                                    <button type="button" class="btn btn-success text-white">Completed</button>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($sale['selling_date']); ?></td>
                            <td>
                                <a href="/view_sale_details/<?php echo e($sale['sales_id']); ?>" class="btn btn-sm btn-inverse btn-outline-primary">
                                    <i class="fas fa-eye "></i>
                                </a>
                                <!-- <a href="/edit_sale_details/<?php echo e($sale['sales_id']); ?>" class="btn btn-sm btn-inverse btn-outline-dark">
                                    <i class="fas fa-pencil-alt "></i>
                                </a> -->
                                <a class="btn btn-sm btn-inverse btn-outline-danger" href="/delete_sale/<?php echo e($sale['sales_id']); ?>/<?php echo e($carDetail->id); ?>"><i class="fas fa-trash-alt"></i></a>
                            </td>
                          </tr>
                          <?php $count++; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if($get_car_id_value ==null && $get_payment_method_value==null && $get_status_value==null && $get_selling_date_value==null): ?>
                    <?php echo e($sales->links()); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/sale/list.blade.php ENDPATH**/ ?>