<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <script>
        $(document).ready(function(){
            $("p").click(function(){
                alert($(this));
            });
        });
        $(document).ready(function () {
            $(document).on('click','.edit_btn', function () {
                var id = $(this).val();
                alert( $(this).val());
                
            });
        });
    </script>
    <br>
    
    <div class="container bg-white">
        <br>
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <h2>Car Records</h2><br>
            </div>
            <div class="col-xd-12 col-sm-2">
                <button class="btn btn-inverse btn-outline-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">Add New Car</button>
                
            </div>
            <div>
                <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
            </div>
        </div>
        <?php
            $day = Carbon\Carbon::now()->format('d');
            if ($day == 1){
                echo "True";
            }
        ?>
        
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Container #</th>
                    <th scope="col">Car Key</th>
                    <th scope="col">Car Name</th>
                    <th scope="col">Purchase Date</th>
                    <th scope="col">Chassis Number</th>
                    <th scope="col">Model</th>
                    <th scope="col">Colour</th>
                    <th scope="col">Engine</th>
                    <th scope="col">Total Price</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $count = 1;?>
                  <?php $__currentLoopData = $cars_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($count); ?></td>
                    <td><?php echo e($car['container_number']); ?></td>
                    <td><?php echo e(str_replace('-',"_",substr($car['created_at'],0,7)) . '_' . $car['id']); ?></td>
                    <td><?php echo e($car['car_name']); ?></td>
                    <td><?php echo e($car['date']); ?></td>
                    <td><?php echo e($car['chassis_number']); ?></td>
                    <td><?php echo e($car['model']); ?></td>
                    <td><?php echo e($car['colour']); ?></td>
                    <td><?php echo e($car['engine']); ?></td>
                    <td><?php echo e($car['japanese_price']+$car['japan_to_durban_price']+$car['durban_to_botswana']+$car['repair_charges']+$car['duty']+$car['vat']); ?></td>
                    <td>
                        <?php if($car['status']==0): ?>
                            Available                        
                        <?php else: ?>
                            Sold
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="/view_car_details/<?php echo e($car['id']); ?>" class="btn btn-sm btn-inverse btn-outline-primary">
                            <i class="fas fa-eye "></i>
                        </a>
                        <a href="/edit_car_details/<?php echo e($car['id']); ?>" class="btn btn-sm btn-inverse btn-outline-dark">
                            <i class="fas fa-pencil-alt "></i>
                        </a>
                        
                        <a class="btn btn-sm btn-inverse btn-outline-danger" href="/delete_car_record/<?php echo e($car['id']); ?>"><i class="fas fa-trash-alt"></i></a>
                    </td>
                  </tr>
                  <?php $count = $count+1;?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
        </div>
    </div>

    <!-- Modal -->
    
    
    
    




    



    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.welcome','data' => []]); ?>
<?php $component->withName('jet-welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->make('add_new_car', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KASPAR PROJECTS\Web App for Botswana\resources\views/cars_management.blade.php ENDPATH**/ ?>