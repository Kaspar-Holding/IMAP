<!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <!-- <div class="sidebar-brand-icon">
          <img src="img/logo/logo2.png">
        </div> -->
        <div class="sidebar-brand-text mx-3" style="padding-top:80px; font-size: large;
    font-weight: bolder;">Car Management</div>
      </a>
      <li class="nav-item" style="padding-top:120px;">
        <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->is('/') ? 'active' : 'link-dark'); ?>" aria-current="page">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      <li class="nav-item mt-3">
        <a href="<?php echo e(route('cars_management')); ?>" class="nav-link <?php echo e(request()->is('cars_management') ? 'active' : 'link-dark'); ?>">
          <i class="fas fa-car-alt"></i>
          <span>Cars Management</span>
        </a>
      </li>
      <li class="nav-item mt-3">
        <a href="<?php echo e(route('sales_management')); ?>" class="nav-link <?php echo e(request()->is('sales_management') ? 'active' : 'link-dark'); ?>">
           <i class="fas fa-car-alt"></i>
          <span>Sales Management</span>
        </a>
      </li>
      <li class="nav-item mt-3">
        <a href="<?php echo e(route('petty_cash_management')); ?>" class="nav-link <?php echo e(request()->is('petty_cash_management') ? 'active' : 'link-dark'); ?>">
           <i class="far fa-file-invoice-dollar"></i>
          <span>Petty Cash Management</span>
        </a>
      </li>
      <?php if(\App\Models\AccessCtrl::isAdmin()): ?>
      <li class="nav-item mt-3">
        <a href="<?php echo e(route('users_management')); ?>" class="nav-link <?php echo e(request()->is('users_management') ? 'active' : 'link-dark'); ?>">
           <i class="fas fa-user-friends"></i>
           <span>User Management</span>
        </a>
      </li>
      <?php endif; ?>
      <!-- <li class="nav-item">
        <a href="<?php echo e(route('petty_cash_management')); ?>" class="nav-link <?php echo e(request()->is('petty_cash_management') ? 'active' : 'link-dark'); ?>">
           <i class="far fa-file-invoice-dollar"></i>
          <span>Profile</span>
        </a>
      </li> -->
      <li class="nav-item" style="padding-top:100px;">
        <a class="nav-link logoutBtn" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
          <i class="fas fa-sign-out fa-chart-area"></i>
          <span>Logout</span>
        </a>
        <form method="POST" id="logout-form" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                            </form>
      </li>

      <li class="nav-item" style="padding-top:300px;">
      <img src="<?php echo e(asset('img/main.png')); ?>">
         
                           
      </li>
    </ul><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/navigation.blade.php ENDPATH**/ ?>