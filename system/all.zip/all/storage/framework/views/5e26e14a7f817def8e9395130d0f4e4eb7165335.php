<div class="d-flex flex-column flex-shrink-0 p-3 bg-white nav_custom" style="font-size:15px">
                    
    <ul class="nav nav-pills flex-column mb-auto ">
        <li class="nav-item">
            <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->is('/') ? 'active' : 'link-dark'); ?>" aria-current="page">
                <i class="fas fa-tachometer-alt"></i>&nbsp;&nbsp;&nbsp;
                Dashboard
            </a>
        </li><hr>
        <li>
            <a href="<?php echo e(route('cars_management')); ?>" class="nav-link <?php echo e(request()->is('cars_management') ? 'active' : 'link-dark'); ?>">
                <i class="fas fa-car-alt"></i>&nbsp;&nbsp;&nbsp;
                Cars Management
            </a>
        </li><hr>
        <li>
            <a href="<?php echo e(route('sales_management')); ?>" class="nav-link <?php echo e(request()->is('sales_management') ? 'active' : 'link-dark'); ?>">
                <i class="fas fa-car-alt"></i>&nbsp;&nbsp;&nbsp;
                Sales Management
            </a>
        </li><hr>
        <li>
            <a href="#" class="nav-link <?php echo e(request()->is('/users_management') ? 'active' : 'link-dark'); ?>">
                <i class="fas fa-user-friends"></i>&nbsp;&nbsp;&nbsp;
                User Management
            </a>
        </li><hr>
        
    </ul>
    
</div><?php /**PATH D:\KASPAR PROJECTS\Web App for Botswana\resources\views/navigation.blade.php ENDPATH**/ ?>