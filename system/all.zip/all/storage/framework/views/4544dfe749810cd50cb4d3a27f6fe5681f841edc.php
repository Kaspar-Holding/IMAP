<?php $__env->startSection('pageTitle','Profile Update'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <h4><?php echo e(Auth::user()->name); ?> Update Profile</h4><br>
            </div>
        </div>      
        <form class="container " action="/update_user_profile" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6">
                    <h5>Name:</h5>
                </div>
                <div class="col-6">
                    <input type="text" class="form-control h5" name="user_name" value="<?php echo e(Auth::user()->name); ?>" id="">
                    <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Email:</h5>
                </div>
                <div class="col-6">
                    <input type="email"  class="form-control h5" name="user_email" value="<?php echo e(Auth::user()->email); ?>">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Change Password:</h5>
                </div>
                <div class="col-6">
                    <input type="password" class="form-control h5" name="user_password" id="">
                </div>
            </div>
            <br>
            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-primary link-light col-sm-4">Update</button>
            </div>
            <br>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/profile/show.blade.php ENDPATH**/ ?>