
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row column_title">
          <div class="col-md-12">
            <div class="page_title">
              <h2>Add User</h2>
            </div>
          </div>
        </div>
         <!-- row -->
        <div class="row">
            <!-- table section -->
          <div class="col-md-12">
            <div class="white_shd full margin_bottom_30">
              <div class="full graph_head">
                <div class="heading1 margin_0">
                  <h2>Add User</h2>
                </div>
              </div>
              <form class="container-fluid" action="/add_user" method="POST">
                <?php echo csrf_field(); ?>
                <div>
                  <label class="form-label">First Name</label>
                  <input type="text" name="first_name" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Last Name</label>
                  <input type="text" name="last_name" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Email</label>
                  <input type="email" name="user_email" class="form-control" required >
                </div>
                <br>
                <div>
                  <label class="form-label">Password</label>
                  <input type="password" name="user_password" class="form-control" required >
                </div>
                <br>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary link-light col-sm-4">Create</button>
                </div>
                <div class="d-flex justify-content-center"></div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jynxProject\resources\views/users/add_user.blade.php ENDPATH**/ ?>