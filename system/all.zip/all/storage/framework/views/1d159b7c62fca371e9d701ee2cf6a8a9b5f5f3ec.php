<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-dark text-uppercase'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/jynxcujg/public_html/system/resources/views/vendor/jetstream/components/button.blade.php ENDPATH**/ ?>