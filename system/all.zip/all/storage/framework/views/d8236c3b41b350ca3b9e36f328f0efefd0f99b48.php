
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <h2><?php echo e($user['name']); ?> Edit Details</h2><br>
            </div>
        </div>      
        <form class="container " action="/edit_user" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-6">
                    <h5>Name:</h5>
                </div>
                <div class="col-6">
                    <input type="text" class="form-control h5" name="user_name" value="<?php echo e($user['name']); ?>" id="">
                    <input type="hidden" name="id" value="<?php echo e($user['id']); ?>">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Email:</h5>
                </div>
                <div class="col-6">
                    <input type="email"  class="form-control h5" name="user_email" value="<?php echo e($user['email']); ?>">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Change Password:</h5>
                </div>
                <div class="col-6">
                    <input type="password" class="form-control h5" name="user_password" id="">
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-6">
                    <h5>Role:</h5>
                </div>
                <div class="col-6">
                    <select name="user_role" class="form-control" required>
                        <option>-- Select --</option>
                        <option value="admin">Admin</option>
                        <option value="manager">Manager</option>
                    </select>
                </div>
            </div>
            <br>
            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-primary link-light col-sm-4">Update</button>
            </div>
            <br>
        </form>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/users/edit.blade.php ENDPATH**/ ?>