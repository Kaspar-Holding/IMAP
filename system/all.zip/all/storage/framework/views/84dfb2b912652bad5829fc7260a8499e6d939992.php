
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $carDetail          = \App\Models\Cars::where('id',$sale['car_id'])->first();
        $installmentDetail  = \App\Models\Installments::where('car_id',$sale['car_id'])->get();
        $installmentDetails = \App\Models\Installments::where('car_id',$sale['car_id'])->first();
        $installmentPaid    = \App\Models\Installments::where('car_id',$sale['car_id'])->where('status','1')->count();
        $installmentPending = \App\Models\Installments::where('car_id',$sale['car_id'])->where('status','0')->count();
        $paidAmount         = \App\Models\Installments::where('car_id',$sale['car_id'])->where('status','1')->sum('installments.installment_price');
    ?>
    <?php if($installmentPaid == $sale['total_installments']): ?>
        <?php
            $status        = \App\Models\Sale::where('car_id',$sale['car_id'])->update(
                        [
                            'status'=>1,
                        ]);
        ?>
    <?php endif; ?>
    <div class="container-fluid" id="container-wrapper" <?php if($installmentPaid == $sale['total_installments']): ?> style="background-image: url(<?= asset('img/completed.png') ?>); background-repeat: no-repeat;background-position: center;" <?php endif; ?>>
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <div class="d-flex" style="justify-content: space-between">
                    <div>
                        <h2>Sale Details</h2><br>
                    </div>
                    <div class="text-right">
                        <a class="btn btn-inverse btn-outline-primary" href="/print_sale_details/<?php echo e($sale['sales_id']); ?>">Print Invoice</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <h5>Customer Name:</h5>
                <h6><?php echo e($sale['customer_name']); ?></h6>
            </div>
            <div class="col-6">
                <h5>Customer Phone:</h5>
                <h6><?php echo e($sale['customer_phone']); ?></h6>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-6">
                <h5>Customer Address:</h5>
                <h6><?php echo e($sale['customer_address']); ?></h6>
            </div>
            <div class="col-6">
                <h5>Car Name:</h5>
                <h6><?php echo e($carDetail->car_name); ?></h6>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-6">
                <h5>Customer Vat Number:</h5>
                <h6><?php echo e($sale['customer_vat_number']); ?></h6>
            </div>
            <div class="col-6">
                <h5>Car Name:</h5>
                <h6><?php echo e($carDetail->car_name); ?></h6>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-6">
                <h5>Car Model:</h5>
                <h6><?php echo e($carDetail->model); ?></h6>
            </div>
            <div class="col-6">
                <h5>Car Chassis Number:</h5>
                <h6><?php echo e($carDetail->chassis_number); ?></h6>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-6">
                <h5>Car Price:</h5>
                <h6><?php echo e($carDetail->japanese_price+$carDetail->japan_to_durban_price+$carDetail->durban_to_botswana+$carDetail->repair_charges+$carDetail->duty+$carDetail->vat); ?></h6>
            </div>
            <div class="col-6">
                <h5>Car Sale Price:</h5>
                <h6><?php echo e($carDetail->sale_amount); ?></h6>
            </div>
        </div>
        <br>
        
        <?php if($sale['payment_method'] == "installments"): ?>
        <div class="row">
            <div class="col-6">
                <h5>Down Payment:</h5>
                <h6><?php echo e($installmentDetails->down_payment); ?></h6>
            </div>
            <div class="col-6">
                <h5>Remaining Amount</h5>
                <?php if($installmentPaid == $sale['total_installments']): ?>
                <h6>0</h6>
                <?php else: ?>
                <h6><?php echo e($installmentDetails->remaining_payment-$paidAmount); ?></h6>
                <?php endif; ?>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-4">
                <h5>Car Sale Date:</h5>
                <h6><?php echo e($sale['selling_date']); ?></h6>
            </div>
            <div class="col-4">
                <h5>Payment Method:</h5>
                <h6><?php if($sale['payment_method'] == "full_payment"): ?>
                        Full Payment
                    <?php else: ?>
                        Installments
                    <?php endif; ?>
                </h6>
            </div>
            <div class="col-4">
                <h5>Paid By:</h5>
                <h6><?php echo e($sale['paid_by']); ?>

                </h6>
            </div>
        </div>
        <br>
        <hr>
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <h2>Installments Details</h2><br>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <h5>Total Installments:</h5>
                <h6><?php echo e($sale['total_installments']); ?></h6>
            </div>
            <div class="col-4">
                <h5>Paid Installments:</h5>
                <h6><?php echo e($installmentPaid); ?></h6>
            </div>
            <div class="col-4">
                <h5>Pending Installments:</h5>
                <h6><?php echo e($installmentPending); ?></h6>
            </div>
        </div>
        <br>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">Installment No</th>
                    <th scope="col">Installment Price</th>
                    <th scope="col">Due Date</th>
                    <th scope="col">Paid Date</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                <?php $count = 1; ?>
                  <?php $__currentLoopData = $installmentDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($count); ?></td>
                    <td><?php echo e($installment->installment_price); ?></td>
                    
                    <td><?php echo e($installment->latest_installment_date); ?></td>
                    <td>
                        <?php if($installment->status == 1): ?>
                            <?php echo e($installment->updated_at); ?>

                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($installment->status == 0): ?>
                            Pending
                        <?php else: ?>
                            Paid
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($installment->status == 0): ?>
                        <a class="btn btn-sm btn-inverse btn-outline-primary" onclick="addToPaid(this)" value="<?php echo $installment->installment_id ; ?>">
                            Click To Pay
                        </a>
                        <?php else: ?>
                        <a class="btn btn-sm btn-inverse btn-outline-danger">Paid</a>
                        <?php endif; ?>
                    </td>
                  </tr>
                  <?php $count++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/sale/view.blade.php ENDPATH**/ ?>