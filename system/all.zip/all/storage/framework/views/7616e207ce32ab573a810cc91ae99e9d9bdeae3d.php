
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <h2>User Add Form</h2><br>
                <?php if($errors->any()): ?>
                <h4><?php echo e($errors->first()); ?></h4>
                <?php endif; ?>
            </div>
        </div>
        <form class="container-fluid" action="/add_user" method="POST">
          <?php echo csrf_field(); ?>
          <div>
            <label class="form-label">Name</label>
            <input type="text" name="user_name" class="form-control" required >
          </div>
          <br>
          <div>
            <label class="form-label">Email</label>
            <input type="email" name="user_email" class="form-control" required >
          </div>
          <br>
          <div>
            <label class="form-label">Password</label>
            <input type="password" name="user_password" class="form-control" required >
          </div>
          <br>
          <div>
            <label class="form-label">User Role</label>
            <select name="user_role" class="form-control" required>
              <option>-- Select --</option>
              <option value="admin">Admin</option>
              <option value="manager">Manager</option>
            </select>
          </div>
          <br>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary link-light col-sm-4">Save</button>
          </div>
          <div class="d-flex justify-content-center"></div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/users/add_user.blade.php ENDPATH**/ ?>