<?php $__env->startSection('pageTitle','User Detail'); ?>
<?php $__env->startSection('content'); ?>

    
    <div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('api.api-token-manager')->html();
} elseif ($_instance->childHasBeenRendered('gTW5Osq')) {
    $componentId = $_instance->getRenderedChildComponentId('gTW5Osq');
    $componentTag = $_instance->getRenderedChildComponentTagName('gTW5Osq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('gTW5Osq');
} else {
    $response = \Livewire\Livewire::mount('api.api-token-manager');
    $html = $response->html();
    $_instance->logRenderedChild('gTW5Osq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jynxcujg/public_html/system/resources/views/api/index.blade.php ENDPATH**/ ?>