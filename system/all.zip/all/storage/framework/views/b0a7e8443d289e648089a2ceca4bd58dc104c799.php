<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
  <br>
  
  <div class="container bg-white" style="background-image: <?php echo e(asset('img/sold.png')); ?>;">
      <br>
      <div class="row">
          <div class="col-xd-12 col-sm-10 ">
              <h2><?php echo e($cars_data[0]['car_name']); ?> (<?php echo e(str_replace('-',"_",substr($cars_data[0]['created_at'],0,7)) . '_' . $cars_data[0]['id']); ?>) Details</h2><br>
          </div>
      </div>
      <?php $__currentLoopData = $cars_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="row">
              <div class="col-6">
                  <h5>Car Availability:</h5>
              </div>
              <div class="col-6">
                  <h5>
                      <?php if($car['status']==0): ?>
                          Available          
                          <a href="/view_car_details/<?php echo e($car['id']); ?>" class="btn btn-md btn-inverse btn-outline-success">
                              SELL
                          </a>              
                      <?php else: ?>
                      <a href="/view_car_details/<?php echo e($car['id']); ?>" class="btn btn-md btn-inverse btn-outline-primary">
                          View Selling Details
                      </a>
                      <?php endif; ?>
                  </h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Car Name:</h5>
              </div>
              <div class="col-6">
                  <h5><?php echo e($car['car_name']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Chassis Number:</h5>
              </div>
              <div class="col-6">
                  <h5><?php echo e($car['chassis_number']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Container Number:</h5>
              </div>
              <div class="col-6">
                  <h5><?php echo e($car['container_number']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Purchase Date:</h5>
              </div>
              <div class="col-6">
                  <h5><?php echo e($car['date']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Car Model:</h5>
              </div>
              <div class="col-6">
                  <h5><?php echo e($car['model']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Car Colour:</h5>
              </div>
              <div class="col-6">
                  <h5><?php echo e($car['colour']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Car Price:</h5>
              </div>
              <div class="col-6">
                  <h5>$ <?php echo e($car['japanese_price']+$car['japan_to_durban_price']+$car['durban_to_botswana']+$car['repair_charges']+$car['duty']+$car['vat']); ?></h5>
              </div>
          </div>
          <hr>
          <h4>Car Price Breakdown</h4>
          <hr>
          <div class="row">
              <div class="col-6">
                  <h5>Japanese Price:</h5>
              </div>
              <div class="col-6">
                  <h5>$ <?php echo e($car['japanese_price']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Japan to Durban Price:</h5>
              </div>
              <div class="col-6">
                  <h5>$ <?php echo e($car['japan_to_durban_price']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Durban to Botswana Price:</h5>
              </div>
              <div class="col-6">
                  <h5>$ <?php echo e($car['durban_to_botswana_price']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>Duty:</h5>
              </div>
              <div class="col-6">
                  <h5>$ <?php echo e($car['duty']); ?></h5>
              </div>
          </div>
          <br>
          <div class="row">
              <div class="col-6">
                  <h5>V.A.T.:</h5>
              </div>
              <div class="col-6">
                  <h5>$ <?php echo e($car['vat']); ?></h5>
              </div>
          </div>
          <br>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <!-- Modal -->
  
  
  
  
  




  



  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.welcome','data' => []]); ?>
<?php $component->withName('jet-welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->make('edit_car', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('add_new_car', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KASPAR PROJECTS\Web App for Botswana\resources\views/edit_car.blade.php ENDPATH**/ ?>