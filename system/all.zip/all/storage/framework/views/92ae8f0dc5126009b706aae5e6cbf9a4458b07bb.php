
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
    <br>
    <div class="row">
      <div class="col-xd-12 col-sm-10 ">
        <h2>Debit Amount Form</h2><br>
      </div>
    </div> 
    <form class="container-fluid" action="/save_petty_debit" method="post">
      <?php echo csrf_field(); ?>
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <input type="hidden" name="remain_cash" id="available_amount_cash" value="<?php echo e(($total_cash_payment+$installment_paid)-$total_cash_debit); ?>">
          <input type="hidden" name="remain_cheque" id="available_amount_cheque" value="<?php echo e($total_cheque_payment-$total_cheque_debit); ?>">
          <div>
            <label class="form-label">Debit From</label>
            <select name="paid_by" class="form-control" id="debits">
              <option>-- Select --</option>
              <option value="cheque">Cheque</option>
              <option value="cash" selected>Cash</option>
            </select>
          </div>
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-lg-12 col-md-12" id="cash">
          <div class="row">
            <div class="col-lg-4">
              <label class="form-label">Available Cash Amount</label>
            </div>
            <div class="col-lg-8">
              <div><b><?php echo e(($total_cash_payment+$installment_paid)-$total_cash_debit); ?></b></div>
            </div>
          </div>
        </div>
        <div class="col-lg-12 col-md-12" id="cheque" style="display: none;">
          <div class="row">
            <div class="col-lg-4">
              <label class="form-label">Available Cheque Amount</label>
            </div>
            <div class="col-lg-8">
              <div><b><?php echo e($total_cheque_payment-$total_cheque_debit); ?></b></div>
            </div>
          </div>
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div>
            <label class="form-label">Debit Amount</label>
            <input type="number" name="debit_amount" id="debit_amount" class="form-control" min="2" max="<?php echo e(($total_cash_payment+$installment_paid)-$total_cash_debit); ?>" required >
          </div>
        </div>
      </div>                
      <br>
      <div class="d-flex justify-content-center">
        <button type="submit" class="btn btn-primary link-light col-sm-4">Debit</button>
      </div>
      <br>
    </form>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/petty/create.blade.php ENDPATH**/ ?>