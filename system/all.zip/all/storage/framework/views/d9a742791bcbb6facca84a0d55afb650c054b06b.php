<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="container-fluid card card-b">
        <div class="row pad">
            <div class="col-xd-12 col-sm-7">
                <h3>Users Lists</h3><br>
            </div> 
            <div>
                <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
       
        <div class="table-responsive" style="padding:10px 0px;">
            <table class="table table-striped">
                <thead>
                  <tr class="a-table"style="background-color:rgb(240 243 255 / 30%);">
                    <th style="border:none;" class="a-table" scope="col">#</th>
                    <th style="border:none;" class="a-table" scope="col">User ID</th>
                    <th style="border:none;" class="a-table" scope="col">First name</th>
                    <th style="border:none;" class="a-table"scope="col">Last name</th>
                    <th style="border:none;"  class="a-table" scope="col">Email</th>
                    <th style="border:none;"  class="a-table" scope="col">Status</th>
                    <!-- <th scope="col">Status</th> -->
                    <th  style="border:none;" class="a-table" scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $count = 1;?>
                  <?php $__currentLoopData = $users_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td class="text-capitalize"><?php echo e($count); ?></td>
                    <td class="text-capitalize"><?php echo e($user['user_id']); ?></td>
                    <td class="text-capitalize"><?php echo e($user['first_name']); ?></td>
                    <td class="text-capitalize"><?php echo e($user['last_name']); ?></td>
                    <td class="text-capitalize"><?php echo e($user['email']); ?></td>
                    <td class="text-capitalize"><?php echo e($user['user_status']); ?></td>
                   
                    <td>
                        <a href="/view_user_details/<?php echo e($user['id']); ?>" class="btn btn-sm btn-inverse btn-outline-primary">
                          Approve  
                        </a>
                       
                    </td>
                  </tr>
                  <?php $count = $count+1;?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
           
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sairarasheed/Desktop/final/resources/views/list.blade.php ENDPATH**/ ?>