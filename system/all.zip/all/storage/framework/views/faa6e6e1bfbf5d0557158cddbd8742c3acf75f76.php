
<?php $__env->startSection('pageTitle','User Detail'); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
               <div class="page_title">
                  <h2>User Details</h2>
               </div>
            </div>
        </div>
         <!-- row -->
        <div class="row">
            <!-- table section -->
            <div class="col-md-12">
               <div class="white_shd full margin_bottom_30">
                    <div class="full graph_head">
                         <div class="heading1 margin_0">
                            <h2><?php echo e($user['first_name']); ?> <?php echo e($user['last_name']); ?> Details</h2>
                         </div>
                    </div>
        
                    <form class="container-fluid" action="/user_status_update" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="row pt-3">
                            <div class="col-6">
                                <h5>First Name:</h5>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control h5" name="first_name" value="<?php echo e($user['first_name']); ?>" disabled>
                                <input type="hidden" name="id" value="<?php echo e($user['user_id']); ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <h5>Last Name:</h5>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control h5" name="last_name" value="<?php echo e($user['last_name']); ?>" disabled>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <h5>Email:</h5>
                            </div>
                            <div class="col-6">
                                <input type="email"  class="form-control h5" name="user_email" value="<?php echo e($user['email']); ?>" disabled>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <h5>Phone Number:</h5>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control h5" name="phone_number" value="<?php echo e($user['phone_number']); ?>" disabled>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <h5>Identification Number:</h5>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control h5" name="identification_num" value="<?php echo e($user['identification_num']); ?>" disabled>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <h5>DOB:</h5>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control h5" name="dob" value="<?php echo e($user['dob']); ?>" disabled>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <h5>Nationality:</h5>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control h5" name="nationality" value="<?php echo e($user['nationality']); ?>" disabled>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-6">
                                <h5>Gender:</h5>
                            </div>
                            <div class="col-6">
                                <input type="text" class="form-control h5" name="gender" value="<?php echo e($user['gender']); ?>" disabled>
                            </div>
                        </div>
                        <br>
                        <div class="d-flex justify-content-center">
                            <button type="submit" class="btn btn-primary link-light col-sm-4">Approve</button>
                        </div>
                        <br>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jynxProject\resources\views/users/view.blade.php ENDPATH**/ ?>