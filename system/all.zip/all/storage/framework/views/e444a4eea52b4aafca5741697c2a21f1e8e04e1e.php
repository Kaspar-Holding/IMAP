<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Pluto - Responsive Bootstrap Admin Panel Templates</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- site icon -->
      <link rel="icon" href="<?php echo e(asset('new/images/fevicon.png')); ?>" type="image/png" />
      <!-- bootstrap css -->
      <link rel="stylesheet" href="<?php echo e(asset('new/css/bootstrap.min.css')); ?>" />
      <!-- site css -->
      <link rel="stylesheet" href="<?php echo e(asset('new/style.css')); ?>" />
      <!-- responsive css -->
      <link rel="stylesheet" href="<?php echo e(asset('new/css/responsive.css')); ?>" />
      <!-- color css -->
      <link rel="stylesheet" href="<?php echo e(asset('new/css/colors.css')); ?>" />
      <!-- select bootstrap -->
      <link rel="stylesheet" href="<?php echo e(asset('new/css/bootstrap-select.css')); ?>" />
      <!-- scrollbar css -->
      <link rel="stylesheet" href="<?php echo e(asset('new/css/perfect-scrollbar.css')); ?>" />
      <!-- custom css -->
      <link rel="stylesheet" href="<?php echo e(asset('new/css/custom.css')); ?>" />
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
      <![endif]-->
   </head> 
   <body class="dashboard dashboard_1">
        <div class="full_container">
            <div class="inner_container">
                <?php echo $__env->make('navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div id="content">
                    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="midde_cont">
                    <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.banner','data' => []]); ?>
<?php $component->withName('jet-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
                        <?php echo $__env->yieldContent('content'); ?>
                        <div class="container-fluid">
                            <div class="footer">
                                <p>Copyright © 2018 Designed by html.design. All rights reserved.<br><br>
                                   Distributed By: <a href="https://themewagon.com/">ThemeWagon</a>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Footer -->    
                </div>
            </div>
        </div>
            <!-- Scroll to top -->
        <script src="<?php echo e(asset('new/js/jquery.min.js')); ?>"></script>
      <script src="<?php echo e(asset('new/js/popper.min.js')); ?>"></script>
      <script src="<?php echo e(asset('new/js/bootstrap.min.js')); ?>"></script>
      <!-- wow animation -->
      <script src="<?php echo e(asset('new/js/animate.js')); ?>"></script>
      <!-- select country -->
      <script src="<?php echo e(asset('new/js/bootstrap-select.js')); ?>"></script>
      <!-- owl carousel -->
      <script src="<?php echo e(asset('new/js/owl.carousel.js')); ?>"></script> 
      <!-- chart js -->
      <script src="<?php echo e(asset('new/js/Chart.min.js')); ?>"></script>
      <script src="<?php echo e(asset('new/js/Chart.bundle.min.js')); ?>"></script>
      <script src="<?php echo e(asset('new/js/utils.js')); ?>"></script>
      <script src="<?php echo e(asset('new/js/analyser.js')); ?>"></script>
      <!-- nice scrollbar -->
      <script src="<?php echo e(asset('new/js/perfect-scrollbar.min.js')); ?>"></script>
      <script>
         var ps = new PerfectScrollbar('#sidebar');
      </script>
      <!-- custom js -->
      <script src="<?php echo e(asset('new/js/custom.js')); ?>"></script>
      <script src="<?php echo e(asset('new/js/chart_custom_style1.js')); ?>"></script>
</body>
            
</html>
<?php /**PATH /Users/sairarasheed/Desktop/final/resources/views/layouts/app.blade.php ENDPATH**/ ?>