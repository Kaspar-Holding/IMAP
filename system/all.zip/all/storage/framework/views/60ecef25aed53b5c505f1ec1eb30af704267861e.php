<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <br>
  <div class="container bg-white" style="background-image: <?php echo e(asset('img/sold.png')); ?>;">
    <br>
    <div class="row">
      <div class="col-xd-12 col-sm-10 ">
        <h2>Sale Form</h2><br>
      </div>
    </div>
    <form class="container " action="/save_sale_car" method="post">
      <?php echo csrf_field(); ?>
      <div>
        <label class="form-label">Car Name</label>
        <select name="car_name" class="form-control" required>
          <option>-- Select --</option>
          <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($car->id); ?>" <?php if($car->id == $id): ?> selected <?php endif; ?>><?php echo e($car->car_key); ?> <?php echo e($car->car_name); ?> <?php echo e($car->model); ?> <?php echo e($car->chassis_number); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <br>
      <div class="row">
        <div class="col-lg-6 col-md-6">
          <div>
            <label class="form-label">Customer Name</label>
            <input type="text" name="customer_name" class="form-control" required >
          </div>
        </div>
        <div class="col-lg-6 col-md-6">
          <div>
            <label class="form-label">Customer Phone No</label>
            <input type="text" name="customer_phone" class="form-control">
          </div>
        </div>
      </div>                
      <br>
      <div class="row">
        <div class="col-lg-6 col-md-6">
          <div>
            <label class="form-label">Customer Address</label>
            <input type="address" name="customer_address" class="form-control">
          </div>
        </div>
        <div class="col-lg-6 col-md-6">
          <div>
            <label class="form-label">Customer VAT Number</label>
            <input type="text" name="customer_vat_number" class="form-control">
          </div>
        </div>
      </div>
      <br>
      <div class="row">
        <div class="col-lg-6 col-md-6">
          <div>
            <label class="form-label">Payment Method</label>
            <select name="payment_method" class="form-control" id="payment_method" required>
              <option>-- Select --</option>
              <option value="full_payment">Full Payment</option>
              <option value="installments">Installments</option>
            </select>
          </div>
        </div>
        <div class="col-lg-6 col-md-6">
          <div>
            <label class="form-label">Paid By</label>
            <select name="paid_by" class="form-control" required>
              <option>-- Select --</option>
              <option value="cheque">Cheque</option>
              <option value="cash">Cash</option>
            </select>
          </div>
        </div>
      </div>
      <br>
      <div id="full_payment" style="display: none;">
        <div>
          <label class="form-label">Sale Amount</label>
          <input type="text" name="sale_amount_total" class="form-control">
        </div>
      </div>
      <div id="installments" style="display: none;">
        <div>
          <label class="form-label">Sale Amount</label>
          <input type="text" name="sale_amount" id="sale_amount" class="form-control">
        </div>
        <br>
        <div>
          <label class="form-label">Down Payment</label>
          <input type="text" name="down_payment" id="down_payment" class="form-control">
        </div>
        <br>
        <div>
          <label class="form-label">Remaining Payment</label>
          <input type="text" name="remaining_payment" id="remaining_payment" readonly class="form-control">
        </div>
        <br>
        <div>
          <label class="form-label">Total Installments</label>
          <input type="text" name="total_installments" class="form-control">
        </div>
      </div>
      <br>
      <div class="d-flex justify-content-center">
        <button type="submit" class="btn btn-primary link-light col-sm-4">save</button>
      </div>
      <br>
    </form>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/sale/sale_car_form.blade.php ENDPATH**/ ?>