
<?php $__env->startSection('pageTitle','Payment Methods'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid" id="container-wrapper">
        <div class="row">
            <div class="col-xd-12 col-sm-10 ">
                <h2>Pending Installments Records</h2><br>
            </div>
            <div>
                <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php
            $day = Carbon\Carbon::now()->format('d');
            if ($day == 1){
                echo "True";
            }
        ?>
        
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Container #</th>
                    <th scope="col">Car Key</th>
                    <th scope="col">Car Name</th>
                    <th scope="col">Total Price</th>
                    <th scope="col">Sale Price</th>
                    <th scope="col">Installment Price</th>
                    <th scope="col">Installment Date</th>
                    <th scope="col">Status</th>
                    <!-- <th scope="col">Action</th> -->
                  </tr>
                </thead>
                <tbody>
                <?php $count = 1; ?>
                  <?php $__currentLoopData = $installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $carDetail = \App\Models\Cars::where('id',$installment['car_id'])->first();
                    ?>
                  <tr>
                    <td><?php echo e($count); ?></td>
                    <td><?php echo e($carDetail->container_number); ?></td>
                    <td><?php echo e(str_replace('-',"_",substr($carDetail->created_at,0,7)) . '_' . $carDetail->id); ?></td>
                    <td><?php echo e($carDetail->car_name); ?></td>
                    
                    <td><?php echo e($carDetail->japanese_price+$carDetail->japan_to_durban_price+$carDetail->durban_to_botswana+$carDetail->repair_charges+$carDetail->duty+$carDetail->vat); ?></td>
                    <td><?php echo e($carDetail->sale_amount); ?></td>
                    <td><?php echo e($installment['installment_price']); ?>

                    </td>
                    <td><?php echo e($installment['latest_installment_date']); ?></td>
                    <td>
                        <?php if($installment['status'] == 0): ?>
                            Pending
                        <?php else: ?>
                            Completed
                        <?php endif; ?>
                    </td>
                    
                    <!-- <td>
                        <a href="/view_sale_details/<?php echo e($installment['installment_id']); ?>" class="btn btn-sm btn-inverse btn-outline-primary">
                            <i class="fas fa-eye "></i>
                        </a>
                    </td> -->
                  </tr>
                  <?php $count++; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($installments->links()); ?>

        </div>
    </div>
    <!-- <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.welcome','data' => []]); ?>
<?php $component->withName('jet-welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\resources\views/sale/pending.blade.php ENDPATH**/ ?>