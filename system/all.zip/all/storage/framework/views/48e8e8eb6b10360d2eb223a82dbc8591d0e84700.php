
<?php $__env->startSection('pageTitle','Event Lists'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row column_title">
            <div class="col-md-12">
               <div class="page_title">
                  <h2>Event Lists</h2>
               </div>
            </div>
        </div>
         <!-- row -->
        <div class="row">
            <!-- table section -->
            <div class="col-md-12">
               <div class="white_shd full margin_bottom_30">
                    <div>
                        <?php echo $__env->make('flashmessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                  <div class="full graph_head">
                     <div class="heading1 margin_0">
                        <div class="row">
                            <div class="col-md-9">
                                <h2>Event Lists</h2>
                            </div>
                            <div class="col-md-3">
                                <a href="/add_new_event" class="btn btn-inverse my-button btn-outline-primary">Create Event</a>
                            </div>
                        </div>
                     </div>
                  </div>
                  <div class="table_section padding_infor_info">
                     <div class="table-responsive-sm">
                        <table class="table table-striped">
                           <thead>
                              <tr>
                                 <th>#</th>
                                 <th>Event Name</th>
                                 <th>Event Date</th>
                                 <th>Dj Name</th>
                                 <th>Event Start Time</th>
                                 <th>Event End Time</th>
                                 <th>QR Generated</th>
                                 <th>Action</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php $count = 1;?>
                              <?php $__currentLoopData = $event_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php
                                $countQr = \App\Models\Bookings::where("event_id",$event['id'])->whereNotNull('booking_id')->count() ;
                              ?>
                              <tr>
                                <td class="text-capitalize"><?php echo e($count); ?></td>
                                <td class="text-capitalize"><?php echo e($event['event_name']); ?></td>
                                <td class="text-capitalize"><?php echo e($event['event_date']); ?></td>
                                <?php if($event->dj == null): ?> 
                                <td class="text-capitalize">Not Assigned</td>
                                <?php else: ?>
                                <td class="text-capitalize"><?php echo e($event->dj->first_name); ?></td>
                                 <?php endif; ?>
                                <td class="text-capitalize"><?php echo e($event['event_start_time']); ?></td>
                                <td class="text-capitalize"><?php echo e($event['event_end_time']); ?></td>
                                <td><?php echo e($countQr); ?></td>
                                <td>
                                    <a href="/edit_event/<?php echo e($event['id']); ?>" class="btn btn-sm btn-blue btn-inverse btn-outline-success">
                                      <i class="fa fa-pencil"></i> 
                                    </a>
                                    <a href="/delete_event/<?php echo e($event['id']); ?>" class="btn btn-sm btn-red btn-inverse btn-outline-danger">
                                      <i class="fa fa-trash"></i> 
                                    </a>
                                   
                                </td>
                              </tr>
                              <?php $count = $count+1;?>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jynxcujg/public_html/system/resources/views/event/list.blade.php ENDPATH**/ ?>