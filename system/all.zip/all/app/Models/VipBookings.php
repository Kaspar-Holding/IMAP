<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VipBookings extends Model
{
    use HasFactory;
    protected $table = 'vip_booth_booking';
}
